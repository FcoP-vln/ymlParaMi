<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductCostPivotTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_cost', function (Blueprint $table) {
            $table->unsignedInteger('product_id');
        $table->foreign('product_id', 'product_id_fk_339982')->references('id')->on('products')->onDelete('cascade');

        $table->unsignedInteger('cost_id');

            $table->foreign('cost_id', 'cost_id_fk_339982')->references('id')->on('costs')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_cost');
    }
}
