<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAccesoryProductPivotTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('accesory_product', function (Blueprint $table) {
           
$table->unsignedInteger('accesory_id');
        $table->foreign('accesory_id', 'accesory_id_fk_339989')->references('id')->on('accesories')->onDelete('cascade');

            $table->unsignedInteger('product_id');
        $table->foreign('product_id', 'product_id_fk_339989')->references('id')->on('products')->onDelete('cascade');


        });
    }

            
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('accesory_product');
    }
}
