<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Receipt;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Gate;  
use App\NumerosEnLetras;
use App\Binnacle;

class ReceiptsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    
    {
        abort_if(Gate::denies('receipts_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.receipts.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $recibo = Receipt::create($request->all());

       //actualiza bitácora
       $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Creó recibo #".$recibo->id." para cliente ".strtoupper($request->input('nombre'));
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return redirect()->route('admin.receipts.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        Receipt::find($id)->update($request->all());

        //actualiza bitácora
       $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Modificó recibo #".$id." del cliente ".strtoupper($request->input('nombre'));
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();


        return redirect()->route('admin.receipts.index');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
       abort_if(Gate::denies('currency_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

       //actualiza bitácora
       $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó recibo #".$id;
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();
      
        //Elimina

        Receipt::find($id)->delete();

 


        return back();
    }
}
