<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyProjectStatusRequest;
use App\Http\Requests\StoreProjectStatusRequest;
use App\Http\Requests\UpdateProjectStatusRequest;
use App\Cost;
use App\Product;
use App\Accesory;
use App\Accesory_product;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use DB;
use App\Binnacle;

class AccesoryProductController extends Controller
{
    public function update(Request $request, Accesory_product $accesory){

     $accesory = DB::table('accesory_product')->Where('id', $accesory->id);


	$accesory->update($request->all());

    //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Modificó accesorio para producto.";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

     return back();
 	// return redirect()->route('admin.products.index');

    }

    public function edit(){
    	 $products = Product::all();
        $accessories = Accesory::all();
         $accesory_product = Accesory_product::all();       

    	return view("admin.accesories.edit2", compact('accessories','products', 'accesory_product'));
    }



}
