<?php

namespace App\Http\Controllers\Admin;

use App\Invoice;
use App\Client;
use App\Quotation;
use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyCurrencyRequest;
use App\Http\Requests\StoreCurrencyRequest;
use App\Http\Requests\UpdateCurrencyRequest;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\DB;

use App\Binnacle;

class InvoiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()    
    {
        abort_if(Gate::denies('bills_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.bills.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
  public function store(Request $request)
    {
       $facturas = Invoice::create($request->all());



        $facturass = Invoice::all();
 
               
        foreach ($facturass as $key => $factura) {
                                                                          
            // $nombre = $factura->quotation->client->first_name;
            // $apellido = $factura->quotation->client->last_name;

                       //instancia para guardar cliente
                        $nom = new Invoice();
                        $nom=Invoice::where('quotation_id', '=', $factura->quotation_id)->first();



                        $cliente = DB::table('clients')->join('quotes', 'clients.id','=','quotes.client_id')->select('clients.first_name', 'clients.last_name')->where('quotes.id', $factura->quotation_id)->get();

                        foreach ($cliente as $key => $cli) {
                            $nom->client = $cli->first_name.' '.$cli->last_name;
                        }



                        $nom->save();
                        $facturass = Invoice::all();
                       
                  }


        //actualiza bitácora
       $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Creó factura #".$facturas->id." para cotización #".$facturas->quotation_id;
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();
        //           
        
         return view('admin.bills.index');
    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       Invoice::find($id)->update($request->all());


        //actualiza bitácora
       $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Modificó factura #".$id;
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();



       return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
