<?php

namespace App\Http\Controllers\Admin;

use App\Client;
use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyProjectRequest;
use App\Http\Requests\StoreProjectRequest;
use App\Http\Requests\UpdateProjectRequest;
use App\Project;
use App\ProjectStatus;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use App\Binnacle;

class ProjectController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('project_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $projects = Project::all();

        return view('admin.projects.index', compact('projects'));
    }

    public function create()
    {
        abort_if(Gate::denies('project_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $clients = Client::all()->pluck('first_name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $statuses = ProjectStatus::all()->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.projects.create', compact('clients', 'statuses'));
    }

    public function store(StoreProjectRequest $request)
    {
        $project = Project::create($request->all());

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Creó nuevo proyecto ".strtoupper($project->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return redirect()->route('admin.projects.index');
    }

    public function edit(Project $project)
    {
        abort_if(Gate::denies('project_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $clients = Client::all()->pluck('first_name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $statuses = ProjectStatus::all()->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $project->load('client', 'status');

        return view('admin.projects.edit', compact('clients', 'statuses', 'project'));
    }

    public function update(UpdateProjectRequest $request, Project $project)
    {
        $project->update($request->all());

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Actualizó información del proyecto ".strtoupper($project->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return redirect()->route('admin.projects.index');
    }

    public function show(Project $project)
    {
        abort_if(Gate::denies('project_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $project->load('client', 'status');

        return view('admin.projects.show', compact('project'));
    }

    public function destroy(Request $request, Project $project)
    {
        abort_if(Gate::denies('project_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó el proyecto ".strtoupper($project->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        $project->delete();

        return back();
    }

    public function massDestroy(MassDestroyProjectRequest $request)
    {
        
         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó varios proyectos";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        Project::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
