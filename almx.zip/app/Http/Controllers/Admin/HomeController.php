<?php

namespace App\Http\Controllers\Admin;
use App\Product;
use App\Cost;
use App\Accesory;
use App\Accesory_product;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use App\Binnacle;
class HomeController
{
    public function index(Request $request)
    {

    	//actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Ingresó a COSTOS DE MATERIA PRIMA";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

       
    return view ('home');

    }
}
