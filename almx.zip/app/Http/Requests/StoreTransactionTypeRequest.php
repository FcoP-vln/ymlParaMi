<?php

namespace App\Http\Requests;

use App\TransactionType;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Symfony\Component\HttpFoundation\Response;

class StoreTransactionTypeRequest extends FormRequest
{
    public function authorize()
    {
        abort_if(Gate::denies('transaction_type_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return true;
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                'unique:transaction_types',
            ],
        ];
    }
}
