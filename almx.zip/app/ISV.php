<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ISV extends Model
{
    use HasFactory;

        public $table = 'isv';


    protected $fillable = [
        'isv',        
        'updated_at',
    ];
}
