<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Accesory_product extends Model
{
    use HasFactory;
    public $table = 'accesory_product';

 protected $hidden = [      
        '_token',
    ];

    protected $fillable = [
        'required',
        'accesory_id',
        'product_id',
        '_token',
        
    ];

public function accesory_product()
    {
        return $this->hasMany(Accesory::class, 'accesory_id', 'id', 'required');
    }    
      public function accessories()
    {

        return $this->belongsToMany(Accesory::class, 'name');
    }     
     public function product()
    {

        return $this->belongsToMany(Product::class);
    }      
   
 }
