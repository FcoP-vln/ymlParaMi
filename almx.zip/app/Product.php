<?php

namespace App;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{

    use SoftDeletes;

    public $table = 'products';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'created_at',
        'updated_at',
        'deleted_at',
        'description',
    ];

     public function product()
    {
        return $this->hasMany(Product::class, 'product_id', 'id', 'required')->withPivot('required');
    }

    public function costs()
    {
        return $this->belongsToMany(Cost::class);
    }

    public function accessories()
    {

        return $this->belongsToMany(Accesory::class)->withPivot('required');
    }
    
    public function accessory_product()
    {

    return $this->belongsToMany(Accesory::class)->withPivot('required','accesory_id','product_id');
    }
    
      
    
}
