<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sobrante extends Model
{
    use HasFactory;
     public $table = 'sobrantes';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];
    protected $fillable = [       
        'quotation_id',
        'material',
        'cantidad',
        'color', 
         'created_at',
        'updated_at',
        'deleted_at',  
        
 ];
}
