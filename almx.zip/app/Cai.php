<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cai extends Model
{
    use HasFactory;
  

    public $table = 'cai';


    protected $fillable = [
        'rango_desde',
        'rango_hasta',
        'cai',
        'fecha_limite',        
        
    ];
}
