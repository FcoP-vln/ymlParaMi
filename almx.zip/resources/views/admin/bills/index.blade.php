@extends('layouts.admin')
@section('content')

<?php
use App\Quotation;
use App\Client;
use App\ClientStatus;
use App\Invoice;
$cotizaciones = Quotation::all()->sortByDesc('id');
$clientes = Client::all();
$statuses = ClientStatus::all();
$facturas = Invoice::all()->sortByDesc('id');

?>

<div class="row">
    <div class="col-sm">
        <h1>{{trans('cruds.bills.title')}}</h1>
        
    </div>
</div>
<!-- Bills header-->
<div class="row">
    <div class="col-sm">
        <p>
            <a href="#new" class="btn btn-success" data-toggle="modal">
                <i class="fa fa-plus"></i> {{trans('cruds.bills.fields.new')}}
            </a>
        </p>   
    </div>

</div>

<!-- Bills body -->
<div class="card">
    <div class="card-header">
       {{trans('cruds.bills.title')}} - {{ trans('global.list') }}
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Quotation">
                <thead>
                <tr>
                    <th width="10"></th>
                    <th>{{trans('cruds.bills.title_singular')}} #</th>
                    <th>{{trans('cruds.quotes.title_singular')}} #</th>
                    <th>{{trans('cruds.bills.fields.client')}}</th>
                    <th>{{trans('cruds.bills.fields.date')}}</th>
                    <th>{{trans('cruds.bills.fields.state')}}</th>
                    <th text-align="center">{{trans('global.datatables.print')}}</th>
                    <th align="center">{{trans('global.edit')}}/RTN</th>

                </tr>
                </thead>
                <tbody>
                @foreach ($facturas as $key=>$factura)
                     <tr data-entry-id="{{ $factura->id }}">
                        <td>
                           
                        </td>
                        <td>000-001-01-00000{{$factura->id ?? ''}}</td>
                        <td>#{{$factura->quotation_id ?? ''}}   
                        </td> 
                                          
                        <td>{{$factura->client ?? ''}}
                        </td>
                        <td>{{ date('d-m-Y', strtotime($factura->invoice_date)) ?? '' }}</td>
                        <td><?php echo htmlentities($factura->estado) ?? '' ?></td>
                        <?php $idC= $factura->quotation_id ?>
                        <td align="center">
                            <a class="btn btn-primary"
                                href='/admin/imprimirFac/?id={{$factura->id}}'onclick="window.open(this.href, 'Cotización#{{$factura->id}}', 'width=700, height=700,');return false;"><i class="fa fa-file-pdf" aria-hidden="true"></i>
                            </a>
                        </td>
                        <td align="center">
                            <a class="btn btn-warning"
                               href="#edit{{$factura->id }}" data-toggle="modal">
                                <i class="fa fa-edit"></i>
                            </a>
                        </td> 
                    </tr>
                                     <!-- MODAL EDITAR-->
                            <div class="modal fade" id="edit{{$factura->id }}" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1>{{trans('global.edit')}} {{trans('cruds.bills.title_singular')}} #000-001-01-00000{{$factura->id}}</h1>
                                                </div>
                                            </div>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                <span aria-hidden="true">&times</span>
                                            </button> 
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="{{ route('admin.bills.update', [$factura->id]) }}" method="POST">
                                                 @csrf
                                                 {{csrf_field()}}
                                                 {{method_field('PUT')}}
                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
                                               </div>
                                            <div class="form-group">

                                                <label for="client">{{trans('cruds.bills.fields.client')}}:</label>
                                                
                                            <input value="{{ old('client', isset($factura) ? $factura->client : '') }}" name="client" autocomplete="off" required type="text"
                                                    class="form-control" id="client" >
                                            </div>
                                              <div class="form-group">

                                                <label for="rtn">RTN:</label>
                                                
                                            <input type="number" min="1" step="1" value="{{ old('rtn', isset($factura) ? $factura->rtn : '') }}" name="rtn" placeholder="Ingrese registro sin guión ni espacios" autocomplete="off" class="form-control" id="rtn" >
                                            </div>
                                            <div class="form-group">

                                              <label for="quotation_id">{{trans('cruds.quotes.title_singular')}}:</label>
                                              <select required class="form-control" name="quotation_id">
                                                <?php foreach ($cotizaciones as $cotizacion) { ?>
                                                  <option value="<?php echo $cotizacion->id ?>" {{(isset($factura) && $factura->quotation_id ? $factura->quotation_id : old ('quotation_id')) == $cotizacion->id ? 'selected' : ''}}><span>#</span>{{$cotizacion->id}}</option>
                                                <?php } ?>
                                              </select>

                                            </div>
                                            <div class="form-group">
                                                <label for="estado">{{trans('cruds.bills.fields.state')}}:</label>
                                                
                                                <select autofocus required class="form-control" id="estado" name="estado" required>
                                                    
                                                        <option  value="<?php echo $factura->estado ?>" {{ (isset($factura) && $factura->estado ? $factura->estado : old('estado')) == $factura->estado  ? 'selected' : '' }}>{{$factura->estado}}
                                                            </option>
                                                            <option>Pendiente</option>
                                                            <option>Cancelada</option>
                                                            <option>NULA</option>
                                                   
                                                </select>
                                            </div>
                                                <div class="form-group">
                                                    <label for="invoice_date">{{trans('cruds.bills.fields.date')}}:</label>
                                                    <input value="{{ old('invoice_date', isset($factura) ? $factura->invoice_date : '') }}" name="invoice_date" autocomplete="off" required type="date"
                                                    class="form-control" id="fecha" >
                                                </div>  

                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="{{trans('cruds.receipts.fields.save_changes')}}">
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                    <!-- fin modal editar -->
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Bills body end -->

<!-- CAI Button -->

<div class="row">
  <div class="col-sm">
<hr><a class="btn btn-dark"
     href="#editCAI" data-toggle="modal">
    <i class="fa fa-edit"><strong>CAI</strong></i>
      </a>
</div>
</div>


<?php 
use App\Cai;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Http\Request;
$rangos = Cai::all();

$cai = new CAI();
$rang = $_POST['id']??'';


if(!$rang==null){
$cai=CAI::where('id', '=', $rang)->first();
  
   // Setear un nuevo rango
   $cai->rango_desde = $_POST['rango_desde'];
   $cai->rango_hasta = $_POST['rango_hasta'];
   $cai->cai = $_POST['cai'];
   $cai->fecha_limite = $_POST['fecha_limite'];
 
   // Guardar en base de datos
   $cai->save();
   $rangos = Cai::all();
}


 ?>

  <div class="row">
    <!-- MODAL CAI rango fACTURAS-->
  <div class="modal fade" id="editCAI" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                        <h3>Rango Autorizado</h3>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="form" action="/admin/bills" method="POST">
               @csrf
               {{csrf_field()}}
               {{method_field('GET')}}
               <div class="form-group">
             <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
            </div>
            @foreach($rangos as $key=>$rango)
            <div class="form-group">
              <input type="hidden" name="id" value="{{$rango->id}}">
              <label>Desde:</label>
             <input class="form-control" type="text"  value="{{$rango->rango_desde}}" name="rango_desde">
                       
            </div>
            <div class="form-group">
  
              <label>Hasta:  </label>
              <input class="form-control" type="text"  value="{{$rango->rango_hasta}}" name="rango_hasta">          
            </div>
            <div class="form-group">
              <label for="cai">CAI:</label>
              <input class="form-control" type="text" name="cai" value="{{$rango->cai}}">
             
             </div>
         
             <div class="form-group">
                <label for="fecha_limite">Fecha límite:</label>
                <input type="date" name="fecha_limite" value="{{$rango->fecha_limite}}">
            </div>  
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Actualizar">
            </div>
            @endforeach
          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal CAI-->
</div>


<div class="row">
    <!-- MODAL CREAR-->
  <div class="modal fade" id="new" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
           
                    	@foreach($facturas as $key=>$facturita)
                        <?php 
                        $new = $facturita->id;
                              $nueva= $new + 1; 
                              break;
                         ?>
                         @endforeach
                        <h3>{{trans('cruds.bills.fields.new')}} #000-001-01-00000{{$nueva ?? ''}}</h3>
                       
                    </div>
                </div> 
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="formAP" action="{{route('admin.bills.store')}}" method="POST">
               @csrf
               {{csrf_field()}}
               {{method_field('POST')}}
               <div class="form-group">
             <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
            </div>
            <div class="form-group">         
            </div>
            <div class="form-group">

                <label for="quotation_id">{{trans('cruds.quotes.title_singular')}}:</label>
                <select required class="form-control" name="quotation_id" id="quotation_id" >
                    <?php foreach ($cotizaciones as $cotizacion) { ?>
                        <option value="<?php echo $cotizacion->id ?>"><span>#</span>{{$cotizacion->id}}</option>
                    <?php } ?>
                </select>
              
             </div>
              
             <div class="form-group">
                <label for="quotation_date">{{trans('cruds.bills.fields.date')}}:</label>
                <input value="<?php echo date("Y-m-d") ?>" name="invoice_date" autocomplete="off" required type="date"
                       class="form-control" id="fecha">
            </div>  
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Crear">
            </div>

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal -->
</div>


@endsection
@section('scripts')
@parent
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
@can('_delete')
  let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "{{ route('admin.quotes.massDestroy') }}",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('{{ trans('global.datatables.zero_selected') }}')

        return
      }

      if (confirm('{{ trans('global.areYouSure') }}')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
@endcan

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  $('.datatable-Quotation:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>
@endsection