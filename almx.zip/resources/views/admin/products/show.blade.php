@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.product.title_singular') }}
    </div>

    <div class="card-body">
        <div class="mb-3">
            <table class="table table-bordered table-striped ">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.product.fields.id') }}
                        </th>
                        <td>
                            {{ $product->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.product.fields.name') }}
                        </th>
                        <td>
                            {{ $product->name }}
                        </td>
                    </tr>
                     <tr>
                        <th>
                            {{ trans('cruds.product.fields.description') }}
                        </th>
                        <td>
                            {{ $product->description }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            Materiales
                        </th>
                        <td>
                            @foreach($product->costs as $id => $costs)

                                <ul class="label label-info label-many">
                                  
                                    <li>
                                       
                                    {{ $costs->name }} ( {{$costs->longsize}}cm) &#8594; Requiere: {{$costs->width_required}} de ancho y {{$costs->high_required}} de alto.
                                    </li>

                                </ul>
                                          @endforeach
                        </td>
                    </tr>
                    <tr>
                        <th>
                            Accesorios
                        </th>
                        <td>
                         @foreach($product->accessories  as $id => $accessories)
                                 
                                <ul class="label label-info label-many">
                                      <li>{{ $accessories->name }} ({{old('required', isset($accessories) ? $accessories->pivot->required: '')}})</li>
                                    </ul>
                                    @endforeach
                        </td>
                    </tr>
                </tbody>
            </table>
            <a style="margin-top:20px;" class="btn btn-default" href="{{ url()->previous() }}">
                {{ trans('global.back_to_list') }}
            </a>
        </div>

        <nav class="mb-3">
            <div class="nav nav-tabs">

            </div>
        </nav>

    </div>
</div>

<br><hr><br>


@endsection
