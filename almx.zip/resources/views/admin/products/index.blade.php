@extends('layouts.admin')
@section('content')
@can('product_create')
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="{{ route('admin.products.create') }}">
                {{ trans('global.add') }} {{ trans('cruds.product.title_singular') }}
            </a>
        </div>
    </div>
@endcan
<div class="card">
    <div class="card-header">
        {{ trans('cruds.product.title') }} - {{ trans('global.list') }}
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Product">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            {{ trans('cruds.product.fields.id') }}
                        </th>
                        <th>
                            {{ trans('cruds.product.fields.name') }}
                        </th>
                        <th>
                            {{ trans('cruds.product.fields.description') }}
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>

                    @foreach($products as $key => $product)
                        <tr data-entry-id="{{ $product->id }}">
                            <td>

                            </td>
                            <td>
                                {{ $product->id ?? '' }}
                            </td>
                            <td>
                                {{ $product->name ?? '' }}
                            </td>
                            <td>
                                {{ $product->description ?? '' }}
                            </td>
                            <td>
                                @can('product_show')
                                    <a class="btn btn-xs btn-primary" href="{{ route('admin.products.show', $product->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                @endcan

                                @can('product_edit')
                                    <a class="btn btn-xs btn-info" href="{{ route('admin.products.edit', $product->id) }}">
                                        {{ trans('global.edit') }}
                                    </a>
                                @endcan

                                @can('product_delete')
                                    <form action="{{ route('admin.products.destroy', $product->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn btn-xs btn-danger" value="{{ trans('global.delete') }}">
                                    </form>
                                @endcan

                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<!--*********************************Accesorio por producto***********************************************************-->
<br><br>

<h1>Accesorio por producto</h1>

<div class="card">
    <div class="card-header">
        {{ trans('global.list') }}
    </div>
 
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-AccesoryProduct">
              
                <thead> 

                    <tr data-entry-id="{{ $product->id }}">
                        <th width="10">

                        </th>
                        <th>
                            Producto_ID
                        </th>
                        <th>
                            Accesorio_ID
                        </th>
                        <th>
                            Requiere:
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
              
                <tbody>                    
                 @foreach($accesory_product as $accesory)
                        <tr >
                            <td scope="row">
                              <!-- {{$accesory->id}} -->
                            </td>
                            <td>
                               {{$accesory->product_id ?? ''}}
                            </td>
                            <td>
                              <!-- {{$accesory->accesory_id}} -->
                                


                                <?php 
                                $name=DB::table('accesories')->select('accesories.name')->where('accesories.id','=',$accesory->accesory_id)->get();
                                foreach ($name as $nombre) {
                                echo $nombre->name ?? '';
                                }
                                ?>  
                       
                            </td>
                            <td class="text-center">
                                {{$accesory->required ?? ''}}
                            </td>  
                            <td>
                               <div class="text-center">
                                <div = "btn-group">
                            
                               @can('product_edit')
                                <a class="btn btn-xs btn-warning pull-right" data-toggle="modal" href="#edit{{$accesory->id}}">Editar</a>
                                @endcan

                                    </div>
                                </div>
                         
                            </td>
                          
                        </tr>
 <!-- MODAL EDITAR-->
  <div class="modal fade" id="edit{{$accesory->id}}" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button>
               
            </div>
            <div class="modal-body">
               <div class="card">
                <div class="card-body">
               <form id="formAP" action="{{route('admin.accesory_product.update', $accesory)}}" method="POST">
               @csrf
               {{csrf_field()}}
               {{method_field('PUT')}}
               
               <div class="form-group">

                <input type="hidden"  name="id" value="{{$accesory->id}}"><br>

                <b> PRODUCTO:</b>
              <input type="text" name="product_id" class="form-control" value="{{$accesory->product_id}}" readonly>
             
                <b>Accesorio:</b>
               <input type="text" name="" class="form-control" value="{{$nombre->name ?? ''}}" readonly>
        
             
              </div>
            </div>
            <div class="card-footer">
              <div class="form-group">
             <b> Requiere:</b>
              <input type="number" style="text-align:center" id="required" step="1" min="1" name="required" value="{{$accesory->required}}"><b> unidades.</b>
            </div>
          </div>
            </div>
            </div>
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Guardar">
            </div>
          </form>
      </div>
    </div>
</div>
</div>
    
<!-- fin modal -->






               @endforeach
                </tbody>
            </table>
      </div>
    </div>   
</div>


           
@endsection
@section('scripts')
@parent
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
@can('product_delete')
  let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "{{ route('admin.products.massDestroy') }}",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('{{ trans('global.datatables.zero_selected') }}')

        return
      }

      if (confirm('{{ trans('global.areYouSure') }}')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
@endcan

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'asc' ]],
    pageLength: 5,
  });
  $('.datatable-Product:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });

});


</script>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)


  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'asc' ]],
    pageLength: 5,
  });
  $('.datatable-AccesoryProduct:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });

});
    

</script>


@endsection