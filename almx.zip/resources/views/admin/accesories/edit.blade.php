@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.accesory.title_singular') }}
    </div>

    <div class="card-body">
        <form action="{{ route("admin.accesories.update", [$accesory->id]) }}" method="POST" enctype="multipart/form-data">
            @csrf
              @method('PUT')
            <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                <label for="name">{{ trans('cruds.accesory.fields.name') }}*</label>
                <input type="text" id="name" name="name" class="form-control" value="{{ old('name', isset($accesory) ? $accesory->name : '') }}" required>
                @if($errors->has('name'))
                    <p class="help-block">
                        {{ $errors->first('name') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.accesory.fields.name_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('price') ? 'has-error' : '' }}">
                <label for="price">{{ trans('cruds.accesory.fields.price') }}*</label>
                <input type="number" min="0" id="price" name="price" class="form-control" value="{{ old('name', isset($accesory) ? $accesory->price : '') }}" step='0.01'  required>
                @if($errors->has('price'))
                    <p class="help-block">
                        {{ $errors->first('price') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.accesory.fields.price_helper') }}
                </p>
            </div>

            <div class="form-group {{ $errors->has('stock') ? 'has-error' : '' }}">
                <label for="stock">{{ trans('cruds.accesory.fields.stock') }} inicial*</label>
                <input type="number" min="0" id="stock" name="stock" class="form-control" value="{{ old('stock', isset($accesory) ? $accesory->stock : '') }}"  required>
                @if($errors->has('stock'))
                    <p class="help-block">
                       {{ $errors->first('stock') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.accesory.fields.stock_helper') }}
                </p>
            </div>            
            <div class="form-group {{ $errors->has('description') ? 'has-error' : '' }}">
                <label for="description">{{ trans('cruds.accesory.fields.description') }}*</label>
                <textarea id="description" name="description" class="form-control " required>{{ old('description', isset($accesory) ? $accesory->description : '') }}</textarea>
                @if($errors->has('description'))
                    <p class="help-block">
                        {{ $errors->first('description') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.accesory.fields.description_helper') }}
                </p>
            </div>
            <div>


            <div>
                <input class="btn btn-danger" type="submit" value="{{ trans('global.save') }}">
                 <a  class="btn btn-default" href="{{ url()->previous() }}">
                {{ trans('global.back_to_list') }}
            </a>
            </div>
        </form>
    </div>
</div>
@endsection