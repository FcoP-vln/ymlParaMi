@extends('layouts.admin')
@section('content')
@can('income_source_create')
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="{{ route("admin.income-sources.create") }}">
                {{ trans('global.add') }} 
            </a>
        </div>
    </div>
@endcan
<div class="card">
    <div class="card-header">
       {{ trans('global.list') }}
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-IncomeSource">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            {{ trans('cruds.incomeSource.fields.id') }}
                        </th>
                        <th>
                            {{ trans('cruds.incomeSource.fields.name') }}
                        </th>
                        <th>
                            {{ trans('cruds.incomeSource.fields.fee_percent') }}
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($incomeSources as $key => $incomeSource)
                        <tr data-entry-id="{{ $incomeSource->id }}">
                            <td>

                            </td>
                            <td>
                                {{ $incomeSource->id ?? '' }}
                            </td>
                            <td>
                                {{ $incomeSource->name ?? '' }}
                            </td>
                            <td>
                                {{ $incomeSource->fee_percent ?? '' }}
                            </td>
                            <td>
                                @can('income_source_show')
                                    <a class="btn btn-xs btn-primary" href="{{ route('admin.income-sources.show', $incomeSource->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                @endcan

                                @can('income_source_edit')
                                    <a class="btn btn-xs btn-info" href="{{ route('admin.income-sources.edit', $incomeSource->id) }}">
                                        {{ trans('global.edit') }}
                                    </a>
                                @endcan

                                @can('income_source_delete')
                                    <form action="{{ route('admin.income-sources.destroy', $incomeSource->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn btn-xs btn-danger" value="{{ trans('global.delete') }}">
                                    </form>
                                @endcan

                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- CAI Button -->

<div class="row">
  <div class="col-sm">
<hr><a class="btn btn-dark"
     href="#editCAI" data-toggle="modal">
    <i class="fa fa-edit"><strong> I . S . V .</strong></i>
      </a>
</div>
</div>


<?php 
use App\ISV;
use App\Binnacle;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Http\Request;

$isv = ISV::all();

$rang = $_POST['id']??'';


if(!$rang==null){


 $isv = new ISV();
$isv=ISV::where('id', '=', $rang)->first();
  //Setear un nuevo isv
$isv->isv = $_POST['isv'];
   
 
//Guardar en base de datos
    $isv->save();
    $isv = ISV::all();

 
    $us = new Binnacle();     
        $us->user_id = auth()->user()->id;
        $us->activity= "Modificó porcentaje de ISV";
        // $us->ip= $request->getClientIp() ?? '';
        $us->save();
        $us = Binnacle::all();
    
}


 ?>

  <div class="row">
    <!-- MODAL I.S.V. cotizaciones-->
  <div class="modal fade" id="editCAI" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                        <h3>I.S.V.</h3>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="form" action="/admin/income-sources" method="POST">
               @csrf
               {{csrf_field()}}
               {{method_field('GET')}}
               <div class="form-group">
            </div>
            @foreach($isv as $key=>$value)
           
            <div class="form-group">
              <label for="cai">I.S.V. %:</label>
               <input type="hidden" name="id" placeholder="{{$value->id}}" value="{{$value->id ?? ''}}">  
              <input class="form-control" type="text" name="isv" value="{{$value->isv ?? ''}}">
             
             </div>                     
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Actualizar">
            </div>
            @endforeach
          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal CAI-->
</div>
@endsection
@section('scripts')
@parent
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
@can('income_source_delete')
  let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "{{ route('admin.income-sources.massDestroy') }}",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('{{ trans('global.datatables.zero_selected') }}')

        return
      }

      if (confirm('{{ trans('global.areYouSure') }}')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
@endcan

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  $('.datatable-IncomeSource:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>
@endsection