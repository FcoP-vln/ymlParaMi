@extends('layouts.admin')
@section('content')
@can('cost_create')
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="{{ route('admin.costs.create') }}">
                {{ trans('global.add') }} {{ trans('cruds.cost.title_singular') }}
            </a>
        </div>
    </div>
@endcan
<div class="card">
    <div class="card-header">
        <label>{{ trans('cruds.cost.title_list') }} - {{ trans('global.list') }}</label>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Cost">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            {{ trans('cruds.cost.fields.id') }}
                        </th>
                        <th>
                            {{ trans('cruds.cost.fields.name') }}
                        </th>
                          <th>
                            {{ trans('cruds.cost.fields.white') }}
                        </th>
                        <th>
                            {{ trans('cruds.cost.fields.bronze') }}
                        </th>
                          <th>
                            {{ trans('cruds.cost.fields.wood') }}
                        </th>
                        <th>
                            {{ trans('cruds.cost.fields.natural') }}
                        </th>
                          <th>
                            {{ trans('cruds.cost.fields.stock') }}
                        </th>
                      
                        <th>
                            {{ trans('cruds.cost.fields.description') }}
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>

                    @foreach($costs as $key => $cost)
                        <tr data-entry-id="{{ $cost->id }}">
                            <td>

                            </td>
                            <td>
                                {{ $cost->id ?? '' }}
                            </td>
                            <td>
                                {{ $cost->name ?? '' }}
                            </td>
                            <td>
                                Lps. {{ $cost->white ?? '' }}
                            </td>
                            <td>
                                Lps. {{ $cost->bronze ?? '' }}
                            </td>
                            <td>
                               Lps. {{ $cost->wood ?? '' }}
                            </td>
                            <td>
                               Lps. {{ $cost->natural ?? '' }}
                            </td>
                            <td>
                              {{$cost->stock ?? ''}}
                            </td>
                           
                            <td>
                                {{ $cost->description ?? '' }}
                            </td>
                            <td>
                                @can('cost_show')
                                    <a class="btn btn-xs btn-primary" href="{{ route('admin.costs.show', $cost->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                @endcan

                                @can('cost_edit')
                                    <a class="btn btn-xs btn-info" href="{{ route('admin.costs.edit', $cost->id) }}">
                                        {{ trans('global.edit') }}
                                    </a>
                                @endcan

                                @can('product_delete')
                                    <form action="{{ route('admin.costs.destroy', $cost->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn btn-xs btn-danger" value="{{ trans('global.delete') }}">
                                    </form>
                                @endcan

                            </td>

                        </tr>

                    @endforeach

                </tbody>

            </table>

        </div>
    </div>
</div>

<br>

@can('accesory_create')
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="{{ route('admin.accesories.create') }}">
               <label> {{ trans('global.add') }} {{ trans('cruds.accesory.title_singular') }}</label>
            </a>
        </div>
    </div>
@endcan
<div class="card">
    <div class="card-header">
      <label>   {{ trans('cruds.accesory.title') }} - {{ trans('global.list') }}</label>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Accesory">
                <thead>
                    <tr align="center">
                        <th width="10">

                        </th>
                        <th>
                            {{ trans('cruds.accesory.fields.id') }}
                        </th>
                        <th>
                            {{ trans('cruds.accesory.fields.name') }}
                        </th>
                        <th>
                            {{ trans('cruds.accesory.fields.price') }}
                        </th>
                         <th>
                            {{ trans('cruds.accesory.fields.stock') }}
                        </th>                       
                        <th>
                            {{ trans('cruds.accesory.fields.description') }}
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>

                    @foreach($accesories as $key => $accesory)
                        <tr data-entry-id="{{ $accesory->id }}">
                            <td>

                            </td>
                            <td>
                                {{ $accesory->id ?? '' }}
                            </td>
                            <td>
                                {{ $accesory->name ?? '' }}
                            </td>
                            <td>
                                Lps. {{ $accesory->price ?? '' }}
                            </td>
                            <td align="center">
                                {{$accesory->stock ?? ''}}
                            </td>
                           
                            <td>
                                {{ $accesory->description ?? '' }}
                            </td>
                            <td>
                                @can('accesory_show')
                                    <a class="btn btn-xs btn-primary" href="{{ route('admin.accesories.show', $accesory->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                @endcan

                                @can('accesory_edit')
                                    <a class="btn btn-xs btn-info" href="{{ route('admin.accesories.edit', $accesory->id) }}">
                                        {{ trans('global.edit') }}
                                    </a>
                                @endcan

                                @can('accesory_delete')
                                    <form action="{{ route('admin.accesories.destroy', $accesory->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn btn-xs btn-danger" value="{{ trans('global.delete') }}">
                                    </form>
                                @endcan

                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>


@endsection
@section('scripts')
@parent
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
@can('cost_delete')
  let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "{{ route('admin.costs.massDestroy') }}",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('{{ trans('global.datatables.zero_selected') }}')

        return
      }

      if (confirm('{{ trans('global.areYouSure') }}')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
@endcan

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 10,
  });
  $('.datatable-Cost:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>

<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
@can('accesory_delete')
  let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "{{ route('admin.accesories.massDestroy') }}",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('{{ trans('global.datatables.zero_selected') }}')

        return
      }

      if (confirm('{{ trans('global.areYouSure') }}')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
@endcan

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 10,
  });
  $('.datatable-Accesory:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>

@endsection