<?php

return [
    'password' => 'Las contraseñas deben tener al menos seis caracteres y coincidir con la confirmación.',
    'reset'    => '¡Su contraseña ha sido restablecida!',
    'sent' => '¡Recordatorio de contraseña enviado!',
    'token' => 'Este token de restablecimiento de contraseña es inválido.',
    'user' => 'No se ha encontrado un usuario con esa dirección de correo.',
    'updated'  => '¡Tu contraseña ha sido cambiada!',
];
