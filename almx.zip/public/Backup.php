
<?php

include './Connet.php';
$day=date("d");
$mont=date("m");
$year=date("Y");
$hora=date("h-i-s");
$fecha=$day.'_'.$mont.'_'.$year;
$DataBASE=$fecha."_(".$hora."_hrs).sql";
$tables=array();
$result=SGBD::sql('SHOW TABLES');


if($result){
    while($row=mysqli_fetch_row($result)){
       $tables[] = $row[0];
    }
    $sql='SET SQL_MODE = '."NO_AUTO_VALUE_ON_ZERO;"."\n\n";
    $sql='START TRANSACTION;'."\n";
    $sql='SET time_zone = "+00:00";'."\n\n";
    $sql.='CREATE DATABASE IF NOT EXISTS '.BD.";\n\n";
    $sql.='USE '.BD.";\n\n";
    foreach($tables as $table){
        $result=SGBD::sql('SELECT * FROM '.$table);
        
        if($result){

            $numFields=mysqli_num_fields($result);
            $sql.='DROP TABLE IF EXISTS '.$table.';';
            $row2=mysqli_fetch_row(SGBD::sql('SHOW CREATE TABLE '.$table));
            $sql.="\n\n".$row2[1].";\n\n"."";

//$sql.='INSERT INTO '.' `'.$table.'`'.' VALUES'."\n";
  
            for ($i=0; $i < $numFields; $i++){

    
                 while($row=mysqli_fetch_row($result)){
                            $sql.='INSERT INTO '.' `'.$table.'`'.' VALUES';   
                     $sql.= "(";
                    for($j=0; $j<$numFields; $j++){

                        $row[$j]=addslashes($row[$j]);
                        $row[$j]=str_replace("\n","\\n",$row[$j]);
                        
                        if (isset($row[$j])){

                            if($row[$j]==NULL){
                                $sql.='NULL';

                            }

                            if(!is_numeric($row[$j]) && !$row[$j]==NULL){
                            $sql .="'".$row[$j]."'";
                        }else{
                           $sql .= "".$row[$j]."" ; 
                        } 


                        }
                        else{
                            $sql.= NULL;
                        }
                        if ($j < ($numFields-1)){
                            $sql .= ',';
                        }
                      
                    }

                     // $sql.= "),\n"; 
                    
                   if($row[$numFields-1]){
                        $sql.= ");\n"; 
                   }else{

                    $CADENA=");";
                 $sql.= $CADENA."\n"; 


                }

                } 

            }
           // $new2.=str_ireplace(",",";",$CADENA);
           // $sql.=$new2;
           //$sql .=str_replace(',', ';');
            $sql.="\n\n\n";
        }else{
        $error=1;
        }


    }
    if($error==1){
        echo 'Ocurrio un error inesperado al crear la copia de seguridad';
    }else{
        chmod(BACKUP_PATH, 0777);
        $sql.='COMMIT;';
        $handle=fopen(BACKUP_PATH.$DataBASE,'w+');
        if(fwrite($handle, $sql)){
            fclose($handle);

         echo "<script>alert('Copia de seguridad realizada con éxito')</script><script>window.location.href = '/backup'</script>";



            
            
            
        }else{
            echo "<script>alert('Ocurrio un error inesperado al crear la copia de seguridad')</script><script>window.location.href = '/backup'</script>";
        }
    }
}else{
    echo 'Ocurrio un error inesperado';
}
mysqli_free_result($result);