-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 16-12-2020 a las 11:29:16
-- Versión del servidor: 10.5.4-MariaDB
-- Versión de PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `alumax_bd`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accesories`
--

DROP TABLE IF EXISTS `accesories`;
CREATE TABLE IF NOT EXISTS `accesories` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `accesories`
--

INSERT INTO `accesories` (`id`, `name`, `price`, `stock`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Vinil para V.F. 3/16 H-730-Negro', '1110.00', 1, '1 rollo de 150m - Negro', '2020-11-07 05:24:24', '2020-11-07 06:42:39', NULL),
(2, 'Felpa 4.8MM negra alta corrediza pesada', '1092.00', 400, 'Rollo de 400m, stock en metros', '2020-11-07 05:26:44', '2020-11-07 06:42:11', NULL),
(3, 'Vinil de malla', '548.69', 465, 'Stock en metros-rollo 465m', '2020-11-07 05:27:51', '2020-11-07 06:40:57', NULL),
(4, 'Tela de fibra de vidrio de 60plg negra', '854.00', 30, 'Malla rollo de 30m', '2020-11-07 05:41:54', '2020-11-07 05:41:54', NULL),
(5, 'Tornillo avellanado 100mmx3plg', '1.20', 10, 'Para ventana v. económica, utiliza 2 unidades', '2020-11-12 06:38:17', '2020-11-12 06:38:42', NULL),
(6, 'Tornillo 8x1 de malla', '0.27', 100, 'utiliza 11 unidades apróx. para ventana aluminio v. económica', '2020-11-12 06:39:26', '2020-11-12 06:39:26', NULL),
(7, 'Tornillo de 10x3/4 para armar', '0.41', 50, 'utiliza 1 para ventana aluminio v. económica', '2020-11-12 06:39:26', '2020-11-12 06:41:06', NULL),
(8, 'Tornillo 10x 1½ para instalar', '0.48', 50, 'Caja de 50 unidades, utiliza apróx. 5 und para ventana económica aluminio.', '2020-11-12 06:43:45', '2020-11-12 06:43:45', NULL),
(9, 'Taco Fisher S-6', '0.29', 180, 'Caja de 180 unidades, 5 para ventana aluminio económica.', '2020-11-12 06:44:53', '2020-11-12 06:44:53', NULL),
(10, 'Tornillo 10x3/8 para sujetador', '0.27', 50, 'Para sujetador de ventana, 2und para económica corrediza.', '2020-11-12 06:50:14', '2020-11-12 06:50:14', NULL),
(11, 'Remaches', '0.20', 200, 'Precio por unidad, caja de 200 unds', '2020-11-12 06:51:11', '2020-11-12 06:51:11', NULL),
(12, 'Escuadra para malla natural', '2.22', 24, 'Caja de 24 unidades, utiliza 4 escuadras para ventana económica.', '2020-11-12 06:52:06', '2020-11-12 06:52:06', NULL),
(13, 'Rodos', '8.88', 50, 'Ninguna.', '2020-11-12 07:00:25', '2020-11-20 12:14:36', NULL),
(14, 'LLavín', '53.55', 10, 'Precio registrado de Color Madera.  Color blanco y bronce 49.14. ajustar para calculo de costos de materiales.', '2020-11-20 12:21:11', '2020-11-20 12:21:11', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accesory_product`
--

DROP TABLE IF EXISTS `accesory_product`;
CREATE TABLE IF NOT EXISTS `accesory_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `required` int(11) DEFAULT NULL,
  `accesory_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `_token` text DEFAULT NULL,
  `_method` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accesory_id_fk_339989` (`accesory_id`),
  KEY `product_id_fk_339989` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `accesory_product`
--

INSERT INTO `accesory_product` (`id`, `required`, `accesory_id`, `product_id`, `_token`, `_method`) VALUES
(189, 5, 8, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(190, 5, 9, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(191, 2, 10, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(192, 1, 11, 1, 'SO7LuXCe3J2aFfoQJCPq45H4EQZ5VsKE8DLxZEnF', 'PUT'),
(193, 4, 12, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(194, 2, 13, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(188, 1, 7, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(187, 11, 6, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(186, 2, 5, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(200, 2, 6, 2, 'jqAibdSCL7y7XNcjWdD7jrAShMNrzw8NeYsyFi01', 'PUT'),
(198, 6, 13, 2, 'ycvsGYEZn0ittsIzEyqyUxwuSv0FIk3nl5GgQSES', 'PUT'),
(205, 2, 14, 2, 'SO7LuXCe3J2aFfoQJCPq45H4EQZ5VsKE8DLxZEnF', 'PUT'),
(195, 1, 14, 1, 'tjH6ZJlXRwQYsaE3d9b1g3PTrz8AGz0WixchQnQi', 'PUT'),
(201, NULL, 7, 2, NULL, NULL),
(202, NULL, 9, 2, NULL, NULL),
(203, 5, 10, 2, 'SO7LuXCe3J2aFfoQJCPq45H4EQZ5VsKE8DLxZEnF', 'PUT'),
(204, 4, 11, 2, 'SO7LuXCe3J2aFfoQJCPq45H4EQZ5VsKE8DLxZEnF', 'PUT');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bills`
--

DROP TABLE IF EXISTS `bills`;
CREATE TABLE IF NOT EXISTS `bills` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint(20) NOT NULL,
  `client` varchar(100) DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `estado` varchar(100) DEFAULT NULL,
  `rtn` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `deleted_at` (`deleted_at`),
  UNIQUE KEY `deleted_at_2` (`deleted_at`)
) ENGINE=MyISAM AUTO_INCREMENT=469 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `bills`
--

INSERT INTO `bills` (`id`, `quotation_id`, `client`, `invoice_date`, `estado`, `rtn`, `created_at`, `updated_at`, `deleted_at`) VALUES
(463, 13491, 'Enrique Bunbury', '2020-12-08', NULL, NULL, '2020-12-08 07:44:44', '2020-12-08 07:44:44', NULL),
(462, 13495, 'Enrique Bunbury', '2020-12-01', 'Cancelada', 801198413383, '2020-12-08 07:13:44', '2020-12-12 22:01:49', NULL),
(464, 13495, 'Enrique Bunbury', '2020-12-12', 'Pendiente', NULL, '2020-12-12 22:01:49', '2020-12-12 22:26:18', NULL),
(465, 13495, NULL, '2020-12-12', NULL, NULL, '2020-12-12 22:37:58', '2020-12-12 22:37:58', NULL),
(466, 13493, 'Enrique Bunbury', '2020-12-12', NULL, NULL, '2020-12-12 22:38:56', '2020-12-12 22:38:56', NULL),
(467, 13492, 'VAN Damme', '2020-12-12', NULL, NULL, '2020-12-12 22:39:30', '2020-12-12 22:39:30', NULL),
(468, 13495, NULL, '2020-12-15', NULL, NULL, '2020-12-15 19:05:48', '2020-12-15 19:05:48', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `binnacles`
--

DROP TABLE IF EXISTS `binnacles`;
CREATE TABLE IF NOT EXISTS `binnacles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `activity` varchar(100) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=275 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `binnacles`
--

INSERT INTO `binnacles` (`id`, `user_id`, `activity`, `ip`, `created_at`, `updated_at`, `deleted_at`) VALUES
(239, 1, 'Creó factura #467 para cotización #13492', '127.0.0.1', '2020-12-12 22:39:30', '2020-12-12 22:39:30', NULL),
(237, 1, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-12 22:38:45', '2020-12-12 22:38:45', NULL),
(238, 1, 'Creó factura #466 para cotización #13493', '127.0.0.1', '2020-12-12 22:38:56', '2020-12-12 22:38:56', NULL),
(236, 1, 'SALIDA', '127.0.0.1', '2020-12-12 22:38:35', '2020-12-12 22:38:35', NULL),
(234, 1, 'Creó recibo #280900 para cliente FRANCISCO', '127.0.0.1', '2020-12-12 22:29:02', '2020-12-12 22:29:02', NULL),
(235, 1, 'Creó factura #465 para cotización #13495', '127.0.0.1', '2020-12-12 22:37:58', '2020-12-12 22:37:58', NULL),
(233, 1, 'Modificó factura #464', '127.0.0.1', '2020-12-12 22:26:18', '2020-12-12 22:26:18', NULL),
(232, 1, 'Se creó permisoBINNACLE_ACCESS', '127.0.0.1', '2020-12-12 22:09:44', '2020-12-12 22:09:44', NULL),
(230, 1, 'Se creó permisoRECEIPTS_ACCESS', '127.0.0.1', '2020-12-12 22:08:36', '2020-12-12 22:08:36', NULL),
(231, 1, 'Se creó permisoBACKUPS_ACCESS', '127.0.0.1', '2020-12-12 22:09:22', '2020-12-12 22:09:22', NULL),
(227, 1, 'SALIDA', '127.0.0.1', '2020-12-12 21:54:29', '2020-12-12 21:54:29', NULL),
(228, 1, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-12 21:54:37', '2020-12-12 21:54:37', NULL),
(229, 1, 'Creó factura #464 para cotización #13495', '127.0.0.1', '2020-12-12 22:01:49', '2020-12-12 22:01:49', NULL),
(226, 1, 'Creó recibo #280916 para cliente FRANCISCO', '127.0.0.1', '2020-12-12 21:37:47', '2020-12-12 21:37:47', NULL),
(225, 1, 'Agregó nuevo producto NUEVO PRODUCTO', '127.0.0.1', '2020-12-12 21:33:22', '2020-12-12 21:33:22', NULL),
(224, 1, 'Agregó nuevo producto PUERTA ABATIBLE PARA BAñO DE VIDRIO TEMPLADO DE 10MM', '127.0.0.1', '2020-12-12 21:25:12', '2020-12-12 21:25:12', NULL),
(222, 1, 'Agregó nuevo producto VENTANA ALUMINIO CORREDIZA ECONóMICA', '127.0.0.1', '2020-12-12 21:23:08', '2020-12-12 21:23:08', NULL),
(223, 1, 'Agregó nuevo producto PUERTA ABATIBLE PARA BAñO DE VIDRIO TEMPLADO DE 10MM', '127.0.0.1', '2020-12-12 21:24:19', '2020-12-12 21:24:19', NULL),
(221, 1, 'Creó cotización #13496 para cliente con id#1', '127.0.0.1', '2020-12-12 21:20:08', '2020-12-12 21:20:08', NULL),
(220, 1, 'Se eliminó usuario NUEVO USUARIO', '127.0.0.1', '2020-12-12 21:18:53', '2020-12-12 21:18:53', NULL),
(215, 1, 'SALIDA', '127.0.0.1', '2020-12-12 21:11:14', '2020-12-12 21:11:14', NULL),
(216, 2, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-12 21:12:13', '2020-12-12 21:12:13', NULL),
(217, 2, 'SALIDA', '127.0.0.1', '2020-12-12 21:16:25', '2020-12-12 21:16:25', NULL),
(218, 1, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-12 21:16:34', '2020-12-12 21:16:34', NULL),
(219, 1, 'Agregó usuario NUEVO USUARIO con email fcopena@unitec.eduo', '127.0.0.1', '2020-12-12 21:18:40', '2020-12-12 21:18:40', NULL),
(240, 1, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-15 17:26:34', '2020-12-15 17:26:34', NULL),
(241, 1, 'Agregó nueva forma de pagoI.S.V', '127.0.0.1', '2020-12-15 17:27:46', '2020-12-15 17:27:46', NULL),
(242, 1, 'Eliminó forma de pagoI.S.V', '127.0.0.1', '2020-12-15 17:27:53', '2020-12-15 17:27:53', NULL),
(243, 1, 'Modificó forma de pagoI.S.V.', '127.0.0.1', '2020-12-15 17:33:22', '2020-12-15 17:33:22', NULL),
(244, 1, 'Modificó forma de pagoI.S.V.', '127.0.0.1', '2020-12-15 17:44:56', '2020-12-15 17:44:56', NULL),
(245, 1, 'Eliminó forma de pagoI.S.V.', '127.0.0.1', '2020-12-15 17:45:30', '2020-12-15 17:45:30', NULL),
(246, 1, 'Modificó porcentaje de ISV.', NULL, '2020-12-15 19:04:46', '2020-12-15 19:04:46', NULL),
(247, 1, 'Creó factura #468 para cotización #13495', '127.0.0.1', '2020-12-15 19:05:48', '2020-12-15 19:05:48', NULL),
(248, 1, 'Se actualizó información del proyecto PROYECTO WALLMART CASCADAS', '127.0.0.1', '2020-12-15 19:51:49', '2020-12-15 19:51:49', NULL),
(249, 1, 'Se creó nuevo proyecto PARA ELIMINAR', '127.0.0.1', '2020-12-15 19:58:15', '2020-12-15 19:58:15', NULL),
(250, 1, 'Se eliminó el proyecto ', '127.0.0.1', '2020-12-15 19:58:21', '2020-12-15 19:58:21', NULL),
(251, 1, 'Se creó nuevo proyecto ELIMINAR', '127.0.0.1', '2020-12-15 19:59:20', '2020-12-15 19:59:20', NULL),
(252, 1, 'Se eliminó el proyecto ELIMINAR', '127.0.0.1', '2020-12-15 19:59:25', '2020-12-15 19:59:25', NULL),
(253, 1, 'Eliminó varias cotizaciones.', '127.0.0.1', '2020-12-15 22:06:17', '2020-12-15 22:06:17', NULL),
(254, 1, 'Modificó accesorio para producto.', '127.0.0.1', '2020-12-15 22:22:42', '2020-12-15 22:22:42', NULL),
(255, 1, 'Ingresó a COSTOS DE MATERIA PRIMA', '127.0.0.1', '2020-12-15 22:23:49', '2020-12-15 22:23:49', NULL),
(256, 1, 'Modificó recibo #280900 del cliente FRANCISCO', '127.0.0.1', '2020-12-15 22:24:51', '2020-12-15 22:24:51', NULL),
(257, 1, 'Actualizó información del producto VENTANA ALUMINIO DOBLE CORREDIZA', '127.0.0.1', '2020-12-15 22:34:49', '2020-12-15 22:34:49', NULL),
(258, 2, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-16 03:15:14', '2020-12-16 03:15:14', NULL),
(259, 2, 'SALIDA', '127.0.0.1', '2020-12-16 03:15:40', '2020-12-16 03:15:40', NULL),
(260, 1, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-16 03:15:47', '2020-12-16 03:15:47', NULL),
(261, 1, 'Modificó accesorio para producto.', '127.0.0.1', '2020-12-16 03:42:44', '2020-12-16 03:42:44', NULL),
(262, 1, 'Modificó accesorio para producto.', '127.0.0.1', '2020-12-16 03:42:55', '2020-12-16 03:42:55', NULL),
(263, 1, 'Modificó accesorio para producto.', '127.0.0.1', '2020-12-16 03:45:25', '2020-12-16 03:45:25', NULL),
(264, 1, 'Modificó accesorio para producto.', '127.0.0.1', '2020-12-16 03:51:12', '2020-12-16 03:51:12', NULL),
(265, 1, 'Modificó accesorio para producto.', '127.0.0.1', '2020-12-16 03:51:40', '2020-12-16 03:51:40', NULL),
(266, 1, 'Modificó accesorio para producto.', '127.0.0.1', '2020-12-16 03:51:48', '2020-12-16 03:51:48', NULL),
(267, 1, 'Actualizó información del producto VENTANA ALUMINIO DOBLE CORREDIZA', '127.0.0.1', '2020-12-16 03:52:34', '2020-12-16 03:52:34', NULL),
(268, 1, 'Modificó accesorio para producto.', '127.0.0.1', '2020-12-16 03:53:35', '2020-12-16 03:53:35', NULL),
(269, 1, 'Actualizó información del producto VENTANA ALUMINIO DOBLE CORREDIZA', '127.0.0.1', '2020-12-16 03:53:41', '2020-12-16 03:53:41', NULL),
(270, 1, 'Eliminó recibo #280900', '127.0.0.1', '2020-12-16 05:20:19', '2020-12-16 05:20:19', NULL),
(271, 1, 'Creó recibo #280901 para cliente FRANCISCO PEñA', '127.0.0.1', '2020-12-16 05:22:42', '2020-12-16 05:22:42', NULL),
(272, 1, 'SALIDA', '127.0.0.1', '2020-12-16 05:30:18', '2020-12-16 05:30:18', NULL),
(273, 1, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-16 05:30:26', '2020-12-16 05:30:26', NULL),
(274, 1, 'INGRESÓ al sistema', '127.0.0.1', '2020-12-16 16:24:58', '2020-12-16 16:24:58', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cai`
--

DROP TABLE IF EXISTS `cai`;
CREATE TABLE IF NOT EXISTS `cai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rango_desde` varchar(100) NOT NULL,
  `rango_hasta` varchar(100) NOT NULL,
  `cai` varchar(100) NOT NULL,
  `fecha_limite` date NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cai`
--

INSERT INTO `cai` (`id`, `rango_desde`, `rango_hasta`, `cai`, `fecha_limite`, `updated_at`) VALUES
(1, '000-0001-01-00000351', '000-0001-01-00000450', '3ECBCB-CEFBEB-9B4BA8-51F261-4C94FD-37', '2020-12-24', '2020-12-08 07:19:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caracteristicas_quotes`
--

DROP TABLE IF EXISTS `caracteristicas_quotes`;
CREATE TABLE IF NOT EXISTS `caracteristicas_quotes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint(20) UNSIGNED NOT NULL,
  `caracteristica` varchar(2550) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_id` (`quotation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `caracteristicas_quotes`
--

INSERT INTO `caracteristicas_quotes` (`id`, `quotation_id`, `caracteristica`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 15, 'Nota: ventanas son de aluminio color blanco lisas, corrediza de una hojas y su malla fija, vidrio bronce o claro o bronce de 5 mm, acabados de primera, sellado, con su instalación correspondiente y garantía de 1 año.                                       ', NULL, NULL, NULL),
(11, 31, 'Nota: ya estoy a verga, espero que con ésta funcione.', '2020-12-02 05:00:11', '2020-12-02 05:00:11', NULL),
(10, 29, 'Que pexis alexis?', '2020-12-01 14:50:54', '2020-12-02 08:21:09', '2020-12-02 08:21:09'),
(12, 32, 'NOTA: ventanas son de aluminio color blanco, lisas y su malla fija. Vidrio bronce de 5mm.\r\nFecha de entrega. 15 días hábiles', '2020-12-02 05:15:43', '2020-12-02 06:31:01', NULL),
(16, 15, 'Fecha de entrega: 15 días hábiles', '2020-12-03 11:01:07', '2020-12-03 11:03:04', NULL),
(15, 28, 'Ayuda a centrar.\r\n                   algo así', '2020-12-02 08:17:36', '2020-12-02 08:20:40', NULL),
(19, 13490, 'Nota: ventanas son de aluminio color blanco lisas, corrediza de una hojas y su malla fija, vidrio bronce o claro o bronce de 5 mm, acabados de primera, sellado, con su instalación correspondiente y garantía de 1 año.', '2020-12-04 13:03:52', '2020-12-04 13:03:52', NULL),
(25, 13491, 'Nota: ventanas son de aluminio color blanco lisas, corrediza de una hoja y su malla fija, vidrio bronce o claro o bronce de 5 mm, acabados de primera, sellado, con su instalación correspondiente y garantía de 1 año.', '2020-12-06 07:42:15', '2020-12-06 07:42:15', NULL),
(26, 13491, 'Fecha de entrega 15 días hábiles.', '2020-12-06 07:42:52', '2020-12-06 07:42:52', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `status_id` int(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_fk_340032` (`status_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `clients`
--

INSERT INTO `clients` (`id`, `first_name`, `last_name`, `company`, `email`, `phone`, `website`, `skype`, `country`, `created_at`, `updated_at`, `deleted_at`, `status_id`) VALUES
(1, 'Enrique', 'Bunbury', 'Personal', 'ebun@yahoo.com', '3395-9090', 'http://portamento.com', 'ebun84', 'Honduras', '2020-10-28 14:10:48', '2020-12-06 07:18:40', NULL, 1),
(2, 'Wallmart', 'Tegucigalpa', 'Wallmart', 'contacto@walmart.com', '2236-8475', 'www.walmart.com.hn', 'Google meet', 'Honduras', '2020-11-07 10:14:21', '2020-11-07 10:19:55', NULL, 1),
(3, 'VAN', 'Damme', NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-06 08:01:04', '2020-12-08 05:57:06', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `client_statuses`
--

DROP TABLE IF EXISTS `client_statuses`;
CREATE TABLE IF NOT EXISTS `client_statuses` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `client_statuses`
--

INSERT INTO `client_statuses` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Activo', '2020-10-28 14:12:04', '2020-10-28 14:12:04', NULL),
(2, 'Inactivo', '2020-10-28 14:12:56', '2020-10-28 14:12:56', NULL),
(3, 'Pendiente', '2020-12-04 08:55:22', '2020-12-04 08:55:22', NULL),
(4, 'Entregado', '2020-12-04 08:55:59', '2020-12-04 08:55:59', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `costs`
--

DROP TABLE IF EXISTS `costs`;
CREATE TABLE IF NOT EXISTS `costs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `white` decimal(15,2) DEFAULT NULL,
  `bronze` decimal(15,2) DEFAULT NULL,
  `wood` decimal(15,2) DEFAULT NULL,
  `natural` decimal(15,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `width_required` float(15,2) UNSIGNED DEFAULT NULL,
  `high_required` float(15,2) UNSIGNED DEFAULT NULL,
  `longsize` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `costs`
--

INSERT INTO `costs` (`id`, `name`, `white`, `bronze`, `wood`, `natural`, `stock`, `width_required`, `high_required`, `longsize`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'JAMBA CABEZAL C/ V ECONÓMICA', '326.67', '326.66', '473.01', '300.83', 3, 1.00, 2.00, 610, 'Para ventana corrediza económica, lance de 6.10m', '2020-11-05 23:45:59', '2020-11-17 04:25:58', NULL),
(2, 'JAMBA LLAVÍN V. ECONÓMICA', '218.48', '218.48', '300.68', '188.58', 2, 0.00, 1.00, 610, 'Para llavín de ventana económica', '2020-11-06 11:53:22', '2020-11-17 07:33:27', NULL),
(3, 'JAMBA HOJA V. ECONÓMICA', '148.56', '148.56', '233.98', '137.06', 4, 2.00, 1.00, 610, 'p/ ventana económica', '2020-11-06 14:29:41', '2020-11-22 03:33:31', NULL),
(4, 'UMBRAL CONTRAMARCO V. ECONÓMICA', '198.55', '198.55', '312.29', '186.91', 10, 1.00, 0.00, 610, 'Para ventana económica, (1 ancho)', '2020-11-07 04:52:10', '2020-11-17 07:10:24', NULL),
(5, 'UMBRAL Y CABEZAL HOJA V. ECONÓMICA', '193.55', '193.55', '293.92', '170.31', 2, 1.00, 0.00, 610, 'Para ventana aluminio corrediza económica', '2020-11-12 06:25:42', '2020-11-17 07:09:41', NULL),
(6, 'MOLDURA DE MALLA', '76.18', '76.18', '82.80', '66.83', 3, 1.00, 2.00, 380, 'Rollo de 3.8m', '2020-11-12 06:29:35', '2020-11-17 07:21:27', NULL),
(8, 'Vinil para V.F. 3/16 H-730-Negro', '1110.00', '1110.00', '1110.00', '1110.00', 1, 2.00, 4.00, 15000, 'Rollo de 150m', '2020-11-20 11:54:57', '2020-11-20 11:57:56', NULL),
(9, 'Felpa 4.8MM negra alta corrediza pesada', '1092.00', '1092.00', '1092.00', '1092.00', 10, 0.00, 2.00, 40000, 'Rollo de 400m. color Negro', '2020-11-20 12:00:07', '2020-11-20 12:33:25', NULL),
(10, 'Vinil de malla', '548.69', '548.69', '548.66', '548.69', 2, 1.00, 2.00, 46500, 'Rollo de 465m', '2020-11-20 12:02:16', '2020-11-20 12:02:39', NULL),
(11, 'Tela de fibra de vidrio de 60plg negra', '854.00', '854.00', '854.00', '854.00', 2, 0.50, 2.00, 3000, 'Rollo de 30m. color negro (único).', '2020-11-20 12:03:48', '2020-11-20 12:04:44', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cost_product`
--

DROP TABLE IF EXISTS `cost_product`;
CREATE TABLE IF NOT EXISTS `cost_product` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `cost_id` int(10) UNSIGNED NOT NULL,
  KEY `product_id_fk_339981` (`product_id`),
  KEY `cost_id_fk_339981` (`cost_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cost_product`
--

INSERT INTO `cost_product` (`product_id`, `cost_id`) VALUES
(1, 8),
(1, 6),
(1, 5),
(1, 4),
(1, 3),
(1, 2),
(1, 1),
(1, 9),
(1, 10),
(1, 11),
(2, 3),
(2, 2),
(2, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `currencies`
--

DROP TABLE IF EXISTS `currencies`;
CREATE TABLE IF NOT EXISTS `currencies` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `main_currency` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `currencies`
--

INSERT INTO `currencies` (`id`, `name`, `code`, `main_currency`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Lempiras', 'Lps', 1, '2020-11-04 04:25:40', '2020-11-06 09:47:06', NULL),
(2, 'Dólares', '$', 0, '2020-11-08 01:11:58', '2020-11-08 01:11:58', NULL),
(3, 'Euros', 'E', 0, '2020-12-03 00:48:50', '2020-12-03 00:49:23', '2020-12-03 00:49:23'),
(4, 'Córdoba', 'C', 0, '2020-12-03 00:49:08', '2020-12-03 00:49:23', '2020-12-03 00:49:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documents`
--

DROP TABLE IF EXISTS `documents`;
CREATE TABLE IF NOT EXISTS `documents` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `project_id` int(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_fk_340053` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `documents`
--

INSERT INTO `documents` (`id`, `name`, `description`, `created_at`, `updated_at`, `deleted_at`, `project_id`) VALUES
(1, 'Doc', 'Para el proyecto Tatumbla', '2020-11-04 04:21:41', '2020-11-04 04:21:41', NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `income_sources`
--

DROP TABLE IF EXISTS `income_sources`;
CREATE TABLE IF NOT EXISTS `income_sources` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `fee_percent` double(15,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `income_sources`
--

INSERT INTO `income_sources` (`id`, `name`, `fee_percent`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Mano de obra', 15.00, '2020-11-04 04:23:34', '2020-11-08 02:08:10', NULL),
(2, 'Flete', 5.00, '2020-11-21 07:17:38', '2020-11-21 07:44:49', '2020-11-21 07:44:49'),
(3, 'Flete', 10.00, '2020-11-21 08:28:49', '2020-11-21 08:28:49', NULL),
(4, 'I.S.V', 15.00, '2020-12-15 17:27:02', '2020-12-15 17:27:53', '2020-12-15 17:27:53'),
(5, 'I.S.V.', 10.00, '2020-12-15 17:27:46', '2020-12-15 17:45:30', '2020-12-15 17:45:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `isv`
--

DROP TABLE IF EXISTS `isv`;
CREATE TABLE IF NOT EXISTS `isv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isv` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `isv`
--

INSERT INTO `isv` (`id`, `isv`, `updated_at`) VALUES
(1, 15, '2020-12-15 18:38:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `disk` varchar(255) NOT NULL,
  `conversions_disk` varchar(255) DEFAULT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` text NOT NULL,
  `custom_properties` text NOT NULL,
  `responsive_images` text NOT NULL,
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `media`
--

INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
(2, 'App\\Document', 1, '1c4af7d8-f92a-486d-8a96-c0478bffcae3', 'document_file', '5fa61c229f3ed_cotizacion vidrio diversa', '5fa61c229f3ed_cotizacion-vidrio-diversa.pdf', 'application/pdf', 'public', 'public', 62244, '[]', '[]', '[]', 1, '2020-11-07 10:02:15', '2020-11-07 10:02:15'),
(3, 'App\\Document', 1, '953cd284-cc1f-465a-bfcb-37711188d0b0', 'document_file', '5fcb3e890c765_Agregar', '5fcb3e890c765_Agregar.JPG', 'image/jpeg', 'public', 'public', 10109, '[]', '{\"generated_conversions\":{\"thumb\":true}}', '[]', 2, '2020-12-05 14:02:30', '2020-12-05 14:02:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(3, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(4, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(5, '2016_06_01_000004_create_oauth_clients_table', 1),
(6, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(7, '2019_09_15_000000_create_media_table', 2),
(8, '2019_09_15_000001_create_permissions_table', 2),
(9, '2019_09_15_000002_create_project_statuses_table', 2),
(10, '2019_09_15_000003_create_transactions_table', 2),
(11, '2019_09_15_000004_create_documents_table', 2),
(12, '2019_09_15_000005_create_notes_table', 2),
(13, '2019_09_15_000006_create_projects_table', 2),
(14, '2019_09_15_000007_create_roles_table', 2),
(15, '2019_09_15_000008_create_clients_table', 2),
(16, '2019_09_15_000009_create_client_statuses_table', 2),
(17, '2019_09_15_000010_create_income_sources_table', 2),
(18, '2019_09_15_000011_create_transaction_types_table', 2),
(19, '2019_09_15_000012_create_currencies_table', 2),
(20, '2019_09_15_000013_create_users_table', 2),
(21, '2019_09_15_000014_create_role_user_pivot_table', 2),
(22, '2019_09_15_000015_create_permission_role_pivot_table', 2),
(23, '2019_09_15_000016_add_relationship_fields_to_clients_table', 2),
(24, '2019_09_15_000017_add_relationship_fields_to_projects_table', 2),
(25, '2019_09_15_000018_add_relationship_fields_to_notes_table', 2),
(26, '2019_09_15_000019_add_relationship_fields_to_documents_table', 2),
(27, '2019_09_15_000020_add_relationship_fields_to_transactions_table', 2),
(28, '2020_11_05_003936_create_costs_table', 3),
(29, '2020_11_05_033107_create_products_table', 4),
(30, '2020_11_06_063515_create_product_cost_pivot_table', 5),
(31, '2020_11_06_180523_create_accesories_table', 6),
(32, '2020_11_07_060826_create_accesory_product_pivot_table', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notes`
--

DROP TABLE IF EXISTS `notes`;
CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `note_text` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `project_id` int(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_fk_340047` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `notes`
--

INSERT INTO `notes` (`id`, `note_text`, `created_at`, `updated_at`, `deleted_at`, `project_id`) VALUES
(1, '4 ventanas\r\n3 puertas', '2020-10-28 14:22:45', '2020-10-28 14:22:45', NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('admin@admin.com', '$2y$10$lGpVb0kHn1h/eEQixox83OY2TM3hPaTrslQIhLVKrdf2YiStZIDay', '2020-11-21 02:46:39');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `permissions`
--

INSERT INTO `permissions` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'user_management_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(2, 'permission_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(3, 'permission_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(4, 'permission_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(5, 'permission_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(6, 'permission_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(7, 'role_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(8, 'role_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(9, 'role_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(10, 'role_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(11, 'role_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(12, 'user_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(13, 'user_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(14, 'user_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(15, 'user_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(16, 'user_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(17, 'client_management_setting_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(18, 'currency_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(19, 'currency_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(20, 'currency_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(21, 'currency_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(22, 'currency_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(23, 'transaction_type_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(24, 'transaction_type_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(25, 'transaction_type_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(26, 'transaction_type_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(27, 'transaction_type_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(28, 'income_source_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(29, 'income_source_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(30, 'income_source_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(31, 'income_source_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(32, 'income_source_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(33, 'client_status_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(34, 'client_status_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(35, 'client_status_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(36, 'client_status_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(37, 'client_status_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(38, 'project_status_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(39, 'project_status_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(40, 'project_status_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(41, 'project_status_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(42, 'project_status_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(43, 'client_management_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(44, 'client_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(45, 'client_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(46, 'client_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(47, 'client_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(48, 'client_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(49, 'project_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(50, 'project_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(51, 'project_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(52, 'project_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(53, 'project_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(54, 'note_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(55, 'note_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(56, 'note_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(57, 'note_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(58, 'note_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(59, 'document_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(60, 'document_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(61, 'document_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(62, 'document_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(63, 'document_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(64, 'transaction_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(65, 'transaction_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(66, 'transaction_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(67, 'transaction_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(68, 'transaction_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(69, 'client_report_create', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(70, 'client_report_edit', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(71, 'client_report_show', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(72, 'client_report_delete', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(73, 'client_report_access', '2019-09-15 12:10:05', '2019-09-15 12:10:05', NULL),
(74, 'cost_access', '2020-11-04 12:41:16', '2020-11-04 12:41:16', NULL),
(75, 'product_access', '2020-11-05 10:52:13', '2020-11-05 10:52:24', NULL),
(76, 'product_delete', '2020-11-05 11:11:58', '2020-11-05 11:11:58', NULL),
(77, 'product_show', '2020-11-05 11:12:10', '2020-11-05 11:14:29', '2020-11-05 11:14:29'),
(78, 'product_show', '2020-11-05 11:12:11', '2020-11-05 11:12:11', NULL),
(79, 'product_edit', '2020-11-05 11:12:32', '2020-11-05 11:12:32', NULL),
(80, 'product_create', '2020-11-05 11:12:44', '2020-11-05 11:12:44', NULL),
(81, 'cost_create', '2020-11-06 04:15:47', '2020-11-06 04:15:47', NULL),
(82, 'cost_delete', '2020-11-06 04:16:09', '2020-11-06 04:16:09', NULL),
(83, 'cost_edit', '2020-11-06 04:16:20', '2020-11-06 04:16:20', NULL),
(84, 'cost_show', '2020-11-06 04:16:44', '2020-11-06 04:16:44', NULL),
(85, 'accesory_access', '2020-11-07 01:08:26', '2020-11-07 01:08:26', NULL),
(86, 'accesory_create', '2020-11-07 01:08:53', '2020-11-07 01:08:53', NULL),
(87, 'accesory_show', '2020-11-07 01:09:13', '2020-11-07 01:09:13', NULL),
(88, 'accesory_edit', '2020-11-07 01:09:27', '2020-11-07 01:09:27', NULL),
(89, 'accesory_delete', '2020-11-07 01:10:20', '2020-11-07 01:10:20', NULL),
(90, 'quotes_access', '2020-12-01 12:53:41', '2020-12-01 12:53:41', NULL),
(91, 'quotes_delete', '2020-12-02 23:33:44', '2020-12-02 23:33:44', NULL),
(92, 'bills_access', '2020-12-05 00:29:45', '2020-12-05 00:29:45', NULL),
(93, 'receipts_access', '2020-12-12 22:08:36', '2020-12-12 22:08:36', NULL),
(94, 'backups_access', '2020-12-12 22:09:22', '2020-12-12 22:09:22', NULL),
(95, 'binnacle_access', '2020-12-12 22:09:44', '2020-12-12 22:09:44', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE IF NOT EXISTS `permission_role` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  KEY `role_id_fk_339981` (`role_id`),
  KEY `permission_id_fk_339981` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `permission_role`
--

INSERT INTO `permission_role` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35),
(1, 36),
(1, 37),
(1, 38),
(1, 39),
(1, 40),
(1, 41),
(1, 42),
(1, 43),
(1, 44),
(1, 45),
(1, 46),
(1, 47),
(1, 48),
(1, 49),
(1, 50),
(1, 51),
(1, 52),
(1, 53),
(1, 54),
(1, 55),
(1, 56),
(1, 57),
(1, 58),
(1, 59),
(1, 60),
(1, 61),
(1, 62),
(1, 63),
(1, 64),
(1, 65),
(1, 66),
(1, 67),
(1, 68),
(1, 69),
(1, 70),
(1, 71),
(1, 72),
(1, 73),
(2, 17),
(2, 18),
(2, 19),
(2, 20),
(2, 21),
(2, 22),
(2, 23),
(2, 24),
(2, 25),
(2, 26),
(2, 27),
(2, 28),
(2, 29),
(2, 30),
(2, 31),
(2, 32),
(2, 33),
(2, 34),
(2, 35),
(2, 36),
(2, 37),
(2, 38),
(2, 39),
(2, 40),
(2, 41),
(2, 42),
(2, 43),
(2, 44),
(2, 45),
(2, 46),
(2, 47),
(2, 48),
(2, 49),
(2, 50),
(2, 51),
(2, 52),
(2, 53),
(2, 54),
(2, 55),
(2, 56),
(2, 57),
(2, 58),
(2, 59),
(2, 60),
(2, 61),
(2, 62),
(2, 63),
(2, 64),
(2, 65),
(2, 66),
(2, 67),
(2, 68),
(2, 90),
(1, 91),
(1, 92),
(1, 90),
(2, 84),
(2, 74),
(1, 74),
(2, 75),
(1, 75),
(1, 76),
(1, 78),
(1, 79),
(1, 80),
(1, 81),
(1, 82),
(1, 83),
(1, 84),
(1, 85),
(1, 86),
(1, 87),
(1, 88),
(1, 89),
(2, 87),
(1, 93),
(1, 94),
(1, 95);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__bookmark`
--

DROP TABLE IF EXISTS `pma__bookmark`;
CREATE TABLE IF NOT EXISTS `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__central_columns`
--

DROP TABLE IF EXISTS `pma__central_columns`;
CREATE TABLE IF NOT EXISTS `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin DEFAULT NULL,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`db_name`,`col_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__column_info`
--

DROP TABLE IF EXISTS `pma__column_info`;
CREATE TABLE IF NOT EXISTS `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__designer_settings`
--

DROP TABLE IF EXISTS `pma__designer_settings`;
CREATE TABLE IF NOT EXISTS `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

--
-- Volcado de datos para la tabla `pma__designer_settings`
--

INSERT INTO `pma__designer_settings` (`username`, `settings_data`) VALUES
('root', '{\"relation_lines\":\"true\",\"angular_direct\":\"angular\",\"snap_to_grid\":\"off\",\"full_screen\":\"off\",\"small_big_all\":\"v\"}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__export_templates`
--

DROP TABLE IF EXISTS `pma__export_templates`;
CREATE TABLE IF NOT EXISTS `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__favorite`
--

DROP TABLE IF EXISTS `pma__favorite`;
CREATE TABLE IF NOT EXISTS `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__history`
--

DROP TABLE IF EXISTS `pma__history`;
CREATE TABLE IF NOT EXISTS `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`,`db`,`table`,`timevalue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__navigationhiding`
--

DROP TABLE IF EXISTS `pma__navigationhiding`;
CREATE TABLE IF NOT EXISTS `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__pdf_pages`
--

DROP TABLE IF EXISTS `pma__pdf_pages`;
CREATE TABLE IF NOT EXISTS `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`page_nr`),
  KEY `db_name` (`db_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

--
-- Volcado de datos para la tabla `pma__pdf_pages`
--

INSERT INTO `pma__pdf_pages` (`db_name`, `page_nr`, `page_descr`) VALUES
('alumax_bd', 1, 'Diagrama 1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__recent`
--

DROP TABLE IF EXISTS `pma__recent`;
CREATE TABLE IF NOT EXISTS `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Volcado de datos para la tabla `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"alumax_bd\",\"table\":\"receipts\"},{\"db\":\"alumax_bd\",\"table\":\"accesory_product\"},{\"db\":\"alumax_bd\",\"table\":\"transaction_types\"},{\"db\":\"alumax_bd\",\"table\":\"transactions\"},{\"db\":\"alumax_bd\",\"table\":\"roles\"},{\"db\":\"alumax_bd\",\"table\":\"binnacles\"},{\"db\":\"alumax_bd\",\"table\":\"projects\"},{\"db\":\"alumax_bd\",\"table\":\"isv\"},{\"db\":\"alumax_bd\",\"table\":\"cai\"},{\"db\":\"alumax_bd\",\"table\":\"income_sources\"}]'),
('', '[{\"db\":\"alumax_bd\",\"table\":\"isv\"},{\"db\":\"alumax_bd\",\"table\":\"cai\"},{\"db\":\"alumax_bd\",\"table\":\"income_sources\"},{\"db\":\"alumax_bd\",\"table\":\"binnacles\"},{\"db\":\"alumax_bd\",\"table\":\"bills\"},{\"db\":\"alumax_bd\",\"table\":\"receipts\"},{\"db\":\"alumax_bd\",\"table\":\"accesories\"},{\"db\":\"alumax_bd\",\"table\":\"users\"},{\"db\":\"alumax_bd\",\"table\":\"clients\"},{\"db\":\"alumax_bd\",\"table\":\"pma__table_coords\"}]');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__relation`
--

DROP TABLE IF EXISTS `pma__relation`;
CREATE TABLE IF NOT EXISTS `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  KEY `foreign_field` (`foreign_db`,`foreign_table`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

--
-- Volcado de datos para la tabla `pma__relation`
--

INSERT INTO `pma__relation` (`master_db`, `master_table`, `master_field`, `foreign_db`, `foreign_table`, `foreign_field`) VALUES
('alumax_bd', 'role_user', 'user_id', 'alumax_bd', 'users', 'id'),
('alumax_bd', 'role_user', 'role_id', 'alumax_bd', 'roles', 'id'),
('alumax_bd', 'permission_role', 'role_id', 'alumax_bd', 'roles', 'id'),
('alumax_bd', 'permission_role', 'permission_id', 'alumax_bd', 'permissions', 'id'),
('alumax_bd', 'projects', 'client_id', 'alumax_bd', 'clients', 'id'),
('alumax_bd', 'clients', 'status_id', 'alumax_bd', 'client_statuses', 'id'),
('alumax_bd', 'projects', 'status_id', 'alumax_bd', 'project_statuses', 'id'),
('alumax_bd', 'documents', 'project_id', 'alumax_bd', 'projects', 'id'),
('alumax_bd', 'notes', 'project_id', 'alumax_bd', 'projects', 'id'),
('alumax_bd', 'oauth_auth_codes', 'client_id', 'alumax_bd', 'clients', 'id'),
('alumax_bd', 'oauth_auth_codes', 'user_id', 'alumax_bd', 'users', 'id'),
('alumax_bd', 'oauth_access_tokens', 'user_id', 'alumax_bd', 'users', 'id'),
('alumax_bd', 'transactions', 'transaction_type_id', 'alumax_bd', 'transaction_types', 'id'),
('alumax_bd', 'cost_product', 'cost_id', 'alumax_bd', 'costs', 'id'),
('alumax_bd', 'cost_product', 'product_id', 'alumax_bd', 'products', 'id'),
('alumax_bd', 'accesory_product', 'product_id', 'alumax_bd', 'products', 'id'),
('alumax_bd', 'accesory_product', 'accesory_id', 'alumax_bd', 'accesories', 'id'),
('alumax_bd', 'caracteristicas_quotes', 'quotation_id', 'alumax_bd', 'quotes', 'id'),
('alumax_bd', 'quotes', 'id', 'alumax_bd', 'servicios_quotes', 'quotation_id');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__savedsearches`
--

DROP TABLE IF EXISTS `pma__savedsearches`;
CREATE TABLE IF NOT EXISTS `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_coords`
--

DROP TABLE IF EXISTS `pma__table_coords`;
CREATE TABLE IF NOT EXISTS `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

--
-- Volcado de datos para la tabla `pma__table_coords`
--

INSERT INTO `pma__table_coords` (`db_name`, `table_name`, `pdf_page_number`, `x`, `y`) VALUES
('alumax_bd', 'users', 1, 91, 176),
('alumax_bd', 'transactions', 1, 95, 1055),
('alumax_bd', 'transaction_types', 1, 580, 1047),
('alumax_bd', 'role_user', 1, 91, 42),
('alumax_bd', 'quotes', 1, 227, 432),
('alumax_bd', 'roles', 1, 329, 29),
('alumax_bd', 'project_statuses', 1, 733, 210),
('alumax_bd', 'projects', 1, 429, 193),
('alumax_bd', 'products', 1, 743, 549),
('alumax_bd', 'permission_role', 1, 532, 67),
('alumax_bd', 'permissions', 1, 782, 27),
('alumax_bd', 'password_resets', 1, 1002, 483),
('alumax_bd', 'oauth_refresh_tokens', 1, 591, 1046),
('alumax_bd', 'oauth_personal_access_clients', 1, 178, 1009),
('alumax_bd', 'oauth_clients', 1, 170, 1285),
('alumax_bd', 'oauth_auth_codes', 1, 76, 428),
('alumax_bd', 'oauth_access_tokens', 1, 64, 612),
('alumax_bd', 'notes', 1, 680, 429),
('alumax_bd', 'media', 1, 145, 1325),
('alumax_bd', 'migrations', 1, 1039, 335),
('alumax_bd', 'income_sources', 1, 192, 1295),
('alumax_bd', 'documents', 1, 1022, 91),
('alumax_bd', 'currencies', 1, 196, 1266),
('alumax_bd', 'cost_product', 1, 924, 584),
('alumax_bd', 'costs', 1, 1163, 611),
('alumax_bd', 'client_statuses', 1, 651, 653),
('alumax_bd', 'clients', 1, 426, 496),
('alumax_bd', 'caracteristicas_quotes', 1, 528, 29),
('alumax_bd', 'accesory_product', 1, 386, 728),
('alumax_bd', 'accesories', 1, 820, 741);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_info`
--

DROP TABLE IF EXISTS `pma__table_info`;
CREATE TABLE IF NOT EXISTS `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`db_name`,`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_uiprefs`
--

DROP TABLE IF EXISTS `pma__table_uiprefs`;
CREATE TABLE IF NOT EXISTS `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`username`,`db_name`,`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Volcado de datos para la tabla `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'alumax_bd', 'accesory_product', '{\"CREATE_TIME\":\"2020-11-07 00:13:06\"}', '2020-11-17 02:57:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__tracking`
--

DROP TABLE IF EXISTS `pma__tracking`;
CREATE TABLE IF NOT EXISTS `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin DEFAULT NULL,
  `data_sql` longtext COLLATE utf8_bin DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (`db_name`,`table_name`,`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__userconfig`
--

DROP TABLE IF EXISTS `pma__userconfig`;
CREATE TABLE IF NOT EXISTS `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Volcado de datos para la tabla `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2020-12-15 18:38:44', '{\"lang\":\"es\",\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__usergroups`
--

DROP TABLE IF EXISTS `pma__usergroups`;
CREATE TABLE IF NOT EXISTS `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N',
  PRIMARY KEY (`usergroup`,`tab`,`allowed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__users`
--

DROP TABLE IF EXISTS `pma__users`;
CREATE TABLE IF NOT EXISTS `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`,`usergroup`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `materials` varchar(255) DEFAULT NULL,
  `accesories` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `name`, `materials`, `accesories`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Ventana aluminio corrediza económica', NULL, NULL, '1 hoja corre.', '2020-11-05 18:24:14', '2020-11-15 05:32:01', NULL),
(2, 'Ventana aluminio doble corrediza', NULL, NULL, '2 hojas corren.', '2020-11-06 03:36:28', '2020-11-20 11:34:05', NULL),
(5, 'Ventana abatible', NULL, NULL, NULL, '2020-12-08 23:59:38', '2020-12-08 23:59:38', NULL),
(6, 'Vidrio Fijo', NULL, NULL, NULL, '2020-12-09 00:14:22', '2020-12-09 00:14:22', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `budget` double(15,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `client_id` int(10) UNSIGNED DEFAULT NULL,
  `status_id` int(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_fk_340038` (`client_id`),
  KEY `status_fk_340042` (`status_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `projects`
--

INSERT INTO `projects` (`id`, `name`, `description`, `start_date`, `budget`, `created_at`, `updated_at`, `deleted_at`, `client_id`, `status_id`) VALUES
(1, 'Proyecto Tatumbla', 'Ventanas y puertas de diferente tamaño, en aluminio y PVC.', '2020-10-29', 15000.00, '2020-10-28 14:22:10', '2020-11-07 10:16:44', NULL, 1, 3),
(2, 'Proyecto Wallmart cascadas', 'Ventanas francesas para exhibición.', '2010-11-20', 18500.00, '2020-11-04 04:36:12', '2020-12-15 19:51:49', NULL, 2, 2),
(3, 'Para eliminar', 'Eliminad', '2020-12-02', 1000.00, '2020-12-15 19:58:15', '2020-12-15 19:58:21', '2020-12-15 19:58:21', 1, 2),
(4, 'Eliminar', 'Eliminad', '2020-12-16', 15000.00, '2020-12-15 19:59:20', '2020-12-15 19:59:25', '2020-12-15 19:59:25', 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `project_statuses`
--

DROP TABLE IF EXISTS `project_statuses`;
CREATE TABLE IF NOT EXISTS `project_statuses` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `project_statuses`
--

INSERT INTO `project_statuses` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'En instalación', '2020-10-28 14:17:33', '2020-10-28 14:18:21', NULL),
(2, 'En espera', '2020-10-28 14:17:42', '2020-10-28 14:17:42', NULL),
(3, 'En producción', '2020-10-28 14:17:51', '2020-10-28 14:17:51', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `quotes`
--

DROP TABLE IF EXISTS `quotes`;
CREATE TABLE IF NOT EXISTS `quotes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(255) NOT NULL,
  `quotation_date` date NOT NULL,
  `descuento` decimal(15,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13496 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `quotes`
--

INSERT INTO `quotes` (`id`, `user_id`, `client_id`, `description`, `quotation_date`, `descuento`, `created_at`, `updated_at`, `deleted_at`) VALUES
(13495, 1, 1, 'Activo', '2020-12-08', NULL, '2020-12-09 00:30:04', '2020-12-12 22:02:23', NULL),
(13494, 2, 1, 'Activo', '2020-12-08', NULL, '2020-12-09 00:30:01', '2020-12-15 22:06:17', '2020-12-15 22:06:17'),
(13493, 2, 1, 'Activo', '2020-12-08', NULL, '2020-12-09 00:29:57', '2020-12-15 22:06:17', '2020-12-15 22:06:17'),
(13490, 1, 1, 'Pendiente', '2020-12-04', '999.99', '2020-12-04 13:00:53', '2020-12-05 06:30:17', NULL),
(13491, 1, 1, 'Pendiente', '2020-12-06', '499.98', '2020-12-06 07:39:53', '2020-12-06 07:41:54', NULL),
(13492, 1, 3, 'Entregado', '2020-12-06', '650.00', '2020-12-06 08:01:19', '2020-12-16 05:06:16', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `receipts`
--

DROP TABLE IF EXISTS `receipts`;
CREATE TABLE IF NOT EXISTS `receipts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `saldo_inicial` decimal(15,2) DEFAULT NULL,
  `abono` decimal(15,2) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=280902 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `receipts`
--

INSERT INTO `receipts` (`id`, `nombre`, `saldo_inicial`, `abono`, `fecha`, `descripcion`, `created_at`, `updated_at`, `deleted_at`) VALUES
(280900, 'Francisco', '75000.00', '25000.00', '2020-12-11', 'Abono datos de la cotización #13495.', '2020-12-12 22:29:02', '2020-12-16 05:20:19', '2020-12-16 05:20:19'),
(280901, 'Francisco Peña', '75000.00', '25000.00', '2020-12-15', 'Adelanto por suministro e instalación de puertas de PVC descrita en la\r\nCOTIZACIÓN # 13213', '2020-12-16 05:22:42', '2020-12-16 05:22:42', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', '2019-09-15 12:09:29', '2019-09-15 12:09:29', NULL),
(2, 'User', '2019-09-15 12:09:29', '2019-09-15 12:09:29', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `role_user`
--

DROP TABLE IF EXISTS `role_user`;
CREATE TABLE IF NOT EXISTS `role_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  KEY `user_id_fk_339990` (`user_id`),
  KEY `role_id_fk_339990` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1),
(2, 2),
(1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios_quotes`
--

DROP TABLE IF EXISTS `servicios_quotes`;
CREATE TABLE IF NOT EXISTS `servicios_quotes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint(20) UNSIGNED NOT NULL,
  `servicio` varchar(255) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `ancho` decimal(15,2) DEFAULT NULL,
  `alto` decimal(15,2) DEFAULT NULL,
  `costo` decimal(9,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_id` (`quotation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `servicios_quotes`
--

INSERT INTO `servicios_quotes` (`id`, `quotation_id`, `servicio`, `cantidad`, `ancho`, `alto`, `costo`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 'Ventana NUEVA', 2, '1.25', '1.25', '1500.00', NULL, '2020-12-01 12:27:40', NULL),
(80, 28, 'Ventana aluminio doble corrediza', 1, '0.50', '0.40', '1000.00', '2020-12-02 08:15:46', '2020-12-02 08:15:46', NULL),
(4, 13, 'Ventana aluminio corrediza económica', 5, '0.40', '0.30', '500.00', '2020-11-30 13:36:19', '2020-12-01 11:35:46', NULL),
(5, 13, 'Ventana aluminio doble corrediza', 7, '0.43', '0.32', '1500.00', '2020-11-30 13:37:10', '2020-12-01 11:17:10', NULL),
(26, 3, 'Ventana aluminio corrediza económica', 2, '0.44', '0.60', '800.00', '2020-12-01 06:41:26', '2020-12-01 11:36:43', NULL),
(66, 30, 'Ventana aluminio corrediza económica', 2, '1.00', '1.00', '1500.00', '2020-12-01 14:52:13', '2020-12-01 14:52:13', NULL),
(17, 3, 'Ventana aluminio doble corrediza', 2, NULL, NULL, '1750.00', '2020-12-01 06:17:45', '2020-12-01 06:17:45', NULL),
(87, 13490, 'Ventana aluminio doble corrediza', 3, '1.50', '2.20', '2500.00', '2020-12-04 13:01:44', '2020-12-04 13:01:44', NULL),
(16, 3, 'Ventana aluminio corrediza económica', 2, NULL, NULL, '2500.00', '2020-11-30 13:46:58', '2020-11-30 13:46:58', NULL),
(86, 13490, 'Ventana aluminio corrediza económica', 1, '1.00', '1.10', '1500.00', '2020-12-04 13:01:27', '2020-12-06 08:06:51', NULL),
(36, 2, 'Ventana aluminio corrediza económica', 2, '1.00', '1.00', '1500.00', '2020-12-01 13:46:26', '2020-12-01 13:46:26', NULL),
(35, 15, 'Ventana aluminio corrediza económica', 2, '1.00', '1.00', '1500.00', '2020-12-01 13:41:31', '2020-12-01 13:41:31', NULL),
(34, 15, 'Ventana aluminio doble corrediza', 3, '1.65', '1.49', '1000.00', '2020-12-01 10:37:04', '2020-12-03 04:02:23', NULL),
(30, 3, 'Ventana aluminio corrediza económica', 1, NULL, NULL, '100.00', '2020-12-01 06:44:13', '2020-12-01 06:44:13', NULL),
(31, 3, 'Ventana aluminio corrediza económica', 1, NULL, NULL, '100.00', '2020-12-01 06:46:22', '2020-12-01 06:46:22', NULL),
(85, 15, 'Ventana aluminio corrediza económica', 1, '1.00', '1.80', '2500.00', '2020-12-03 04:02:03', '2020-12-03 04:02:03', NULL),
(33, 5, 'Ventana aluminio doble corrediza', 3, '0.85', '0.40', '3300.00', '2020-12-01 06:48:20', '2020-12-01 06:48:20', NULL),
(58, 15, 'Puerta nueva', 2, '15.00', '12.00', '2750.00', '2020-12-01 14:43:53', '2020-12-02 06:35:23', NULL),
(84, 27, 'Ventana aluminio corrediza económica', 1, '1.00', '1.00', '500.00', '2020-12-02 12:31:45', '2020-12-02 12:31:45', NULL),
(83, 16, 'Ventana aluminio corrediza económica', 2, '0.58', '0.50', '848.00', '2020-12-02 12:23:58', '2020-12-02 12:23:58', NULL),
(53, 17, 'NUEVO', 2, '15.00', '15.00', '850.00', '2020-12-01 14:32:32', '2020-12-01 14:33:26', NULL),
(52, 25, NULL, NULL, NULL, NULL, NULL, '2020-12-01 14:27:22', '2020-12-01 14:27:22', NULL),
(69, 30, NULL, NULL, NULL, NULL, NULL, '2020-12-01 14:53:55', '2020-12-01 14:53:55', NULL),
(70, 30, NULL, NULL, NULL, NULL, NULL, '2020-12-02 04:32:44', '2020-12-02 04:32:44', NULL),
(71, 30, NULL, NULL, NULL, NULL, NULL, '2020-12-02 04:32:45', '2020-12-02 04:32:45', NULL),
(72, 31, 'Ventana aluminio corrediza económica', 1, '1.00', '1.00', '1500.00', '2020-12-02 04:39:36', '2020-12-02 04:39:36', NULL),
(73, 31, 'Ventana aluminio corrediza económica', 1, '1.00', '1.00', '1500.00', '2020-12-02 04:39:36', '2020-12-02 04:39:36', NULL),
(74, 31, 'Ventana aluminio doble corrediza', 2, '1.00', '1.00', '1000.00', '2020-12-02 04:41:02', '2020-12-02 04:41:02', NULL),
(75, 31, 'Ventana aluminio doble corrediza', 2, '1.00', '1.00', '1000.00', '2020-12-02 04:41:02', '2020-12-02 04:41:02', NULL),
(76, 31, 'Ventana aluminio corrediza económica', 2, '1.50', '1.50', '2500.00', '2020-12-02 04:42:17', '2020-12-02 04:42:42', NULL),
(77, 31, 'Ventana aluminio doble corrediza', 1, '0.45', '0.48', '750.00', '2020-12-02 04:59:45', '2020-12-02 04:59:45', NULL),
(78, 32, 'Ventana aluminio doble corrediza', 2, '1.40', '1.50', '3500.00', '2020-12-02 05:11:51', '2020-12-02 06:30:44', NULL),
(81, 28, 'Ventana aluminio corrediza económica', 1, '1.01', '1.01', '100.00', '2020-12-02 08:17:17', '2020-12-02 08:17:47', '2020-12-02 08:17:47'),
(82, 28, 'Ventana aluminio corrediza económica', 1, '0.40', '0.30', '123.00', '2020-12-02 08:18:01', '2020-12-02 08:19:46', '2020-12-02 08:19:46'),
(88, 18, 'Ventana aluminio corrediza económica', 2, '1.00', '0.50', '1500.00', '2020-12-05 11:16:07', '2020-12-05 11:16:07', NULL),
(89, 18, 'Ventana aluminio doble corrediza', 2, '0.52', '0.30', '2500.00', '2020-12-05 11:16:31', '2020-12-05 11:16:31', NULL),
(90, 18, 'Ventana aluminio doble corrediza', 1, '0.45', '0.58', '850.00', '2020-12-05 11:16:48', '2020-12-05 11:16:48', NULL),
(91, 18, 'Ventana aluminio corrediza económica', 3, '85.00', '4.00', '850.00', '2020-12-05 11:17:00', '2020-12-05 11:17:00', NULL),
(92, 18, 'Puerta abatible para baño de vidrio templado de 10mm', 1, '3.00', '4.00', '4500.00', '2020-12-05 11:17:12', '2020-12-05 11:33:28', NULL),
(93, 18, 'Puerta abatible para baño de vidrio templado de 10mm', 1, '2.71', '2.10', '29695.00', '2020-12-05 11:18:34', '2020-12-05 11:35:20', NULL),
(94, 18, 'Mampara fija de vidrio templado de 10 mm', 1, '1.00', '2.10', '12695.00', '2020-12-05 11:18:58', '2020-12-05 11:20:27', NULL),
(95, 18, 'Mampara fija de vidrio templado de 10 mm', 1, '0.51', '1.80', '5600.00', '2020-12-05 11:19:19', '2020-12-05 11:20:18', NULL),
(96, 18, 'Mampara fija de vidrio templado de 10 mm', 1, '0.75', '1.80', '7900.00', '2020-12-05 11:19:38', '2020-12-05 11:20:01', NULL),
(97, 13491, 'Ventana aluminio corrediza económica', 2, '1.50', '0.52', '4500.00', '2020-12-06 07:40:53', '2020-12-06 07:41:19', NULL),
(98, 13491, 'Ventana aluminio doble corrediza', 3, '1.50', '4.50', '2500.00', '2020-12-06 07:41:33', '2020-12-06 07:41:33', NULL),
(99, 13491, 'Puerta abatible para baño de vidrio templado de 10mm', 4, '2.00', '2.50', '17500.00', '2020-12-06 07:44:10', '2020-12-06 08:35:14', NULL),
(100, 5, 'Ventana aluminio corrediza económica', 2, '12.00', '12.00', '4500.00', '2020-12-06 08:50:55', '2020-12-06 08:50:55', NULL),
(101, 13492, 'Puerta abatible para baño de vidrio templado de 10mm', 1, '1.50', '2.10', '7500.00', '2020-12-08 23:38:19', '2020-12-08 23:39:05', NULL),
(102, 13492, 'Ventana abatible', 2, '1.20', '2.70', '3500.00', '2020-12-08 23:57:35', '2020-12-08 23:57:56', NULL),
(103, 13492, 'Vidrio Fijo', 1, '1.00', '1.00', '150.00', '2020-12-09 00:13:57', '2020-12-09 00:14:22', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `amount` decimal(15,2) DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `project_id` int(10) UNSIGNED DEFAULT NULL,
  `transaction_type_id` int(10) UNSIGNED DEFAULT NULL,
  `income_source_id` int(10) UNSIGNED DEFAULT NULL,
  `currency_id` int(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_fk_340061` (`project_id`),
  KEY `transaction_type_fk_340062` (`transaction_type_id`),
  KEY `income_source_fk_340063` (`income_source_id`),
  KEY `currency_fk_340065` (`currency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `transactions`
--

INSERT INTO `transactions` (`id`, `amount`, `transaction_date`, `name`, `description`, `created_at`, `updated_at`, `deleted_at`, `project_id`, `transaction_type_id`, `income_source_id`, `currency_id`) VALUES
(1, '1500.00', '2020-11-03', 'Transacción', 'Para probar el sistema', '2020-11-04 04:26:27', '2020-11-07 10:46:29', NULL, 1, 1, 1, 1),
(2, '850.00', '2020-11-11', 'Francisco', 'Esperar respuesta', '2020-11-04 04:40:36', '2020-11-21 07:26:49', NULL, 2, 2, 1, 2),
(3, '1000.00', '2020-11-20', 'Remodelación', 'Remodelación', '2020-11-21 08:24:02', '2020-11-21 08:24:02', NULL, 2, 1, 1, 2),
(4, '500.00', '2020-11-20', 'Peña', 'Flete', '2020-11-21 08:29:31', '2020-11-21 08:30:06', NULL, 2, 2, 3, 2),
(5, '5000.00', '2020-11-22', 'Fco', 'qwerty', '2020-11-22 03:37:55', '2020-11-22 03:37:55', NULL, 1, 1, 3, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transaction_types`
--

DROP TABLE IF EXISTS `transaction_types`;
CREATE TABLE IF NOT EXISTS `transaction_types` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `transaction_types`
--

INSERT INTO `transaction_types` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Efectivo', '2020-11-04 04:24:18', '2020-11-04 04:24:18', NULL),
(2, 'Débito', '2020-11-07 10:06:34', '2020-11-07 10:06:34', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', 'admin@admin.com', NULL, '$2y$10$m0tdtBpNZwmyy//osdaCfeKlq5iJnOycUTrXlPBMtFQiaeaF27/R2', 'Wt2QzOSa8pxlx0qiYsqgaFGi280xo5KE1kIjZeAFn2YNOtvLuBhry66Bi8qm', '2019-09-15 12:09:29', '2020-12-06 08:53:42', NULL),
(2, 'Peña', 'fcopena@unitec.edu', NULL, '$2y$10$ZSPzB/Lwtiuao2OeChOJjux/2b6Jdl5aj9i3sNplFF7H/8YirosMa', 'UvRXyZF2hE71umwgHndTQJYEBiSAJpjEVt2u9IqIJ9pmr7FL448RGHCrBgmj', '2020-10-28 12:58:10', '2020-12-08 09:50:05', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
