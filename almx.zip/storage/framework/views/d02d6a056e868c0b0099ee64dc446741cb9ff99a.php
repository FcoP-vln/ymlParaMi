 
 <title><?php echo e(trans('panel.site_title')); ?></title>
  
<?php

use App\NumerosEnLetras;
use App\Receipt;
use Symfony\Component\HttpFoundation\Response;
setlocale(LC_TIME, 'es_ES', 'esp_esp'); 


$id= $_GET["id"];
if (empty($_GET["id"])) {
    exit;
}
 

if(!Receipt::find($id)){
    echo (Response::HTTP_FORBIDDEN.' | Forbidden');
    return back();
}else{
    $Recibos = Receipt::find($id)->where('id', $id)->get();
    // $cotizacion = Invoice::find($id)->where('id', $id)->get('quotation_id');
}
// if (!$cotizacion) {
//     exit("No existe la cotización");
// }

?>
<meta http-equiv="content-type" content="text/html; utf-8">
<div>
    <br><br>
        <div class="col-sm" align="center">
            <p style="font-size: xx-small;"><img src="./img/Logo3.png"><br>INVERSIONES DIVERSAS DE ORIENTE S. DE R.L.<br>
                Col. Villa Vieja 3.5 km carretera a Danli, frente a Yonker Jireh, Tegucigalpa M.D.C.<br>
                Tel. :(504) 2243-2948 / 3362-2139, Correo: alumax.hn@gmail.com<br>
            R.T.N. 08019017957660 </p>
        </div>
        <br><br><br><br>

        <div class="row">
       
             <?php $__currentLoopData = $Recibos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recibo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <table><tbody>
                <tr>
                    <td width ="100px">
                     <strong style="margin-left: 35px;">RECIBO No.<?php echo e($id); ?></strong>
                    </td>
                    <td width ="150px">
                    </td>
                    <td width ="100px">
                    </td>
                    <td width ="100px" align="right">
                    <strong>POR LPS.</strong>
                    </td>
                <td align="center" style=" border: 2px solid black; padding: 4px;" width="100px">
                    <?php echo e(number_format($recibo->abono,2)); ?>

                </td>
                <tr>

                </tbody></table>

        </div>

        <br>

        <div class="row" >            

               <strong style="font-size: small; margin-left: 38px; font-size: small;">Recibí de: <?php echo e(strtoupper($recibo->nombre)); ?></strong>
        </div>
        <br><br>

        <div class="row" style="font-size: small; margin-left: 38px; font-size: small;">
            <?php 
$letras_total=NumerosEnLetras::convertir($recibo->abono,'lempiras',false,'centavos');
             ?>

           <strong>La cantidad de: <?php echo e(lcfirst($letras_total)); ?>.</strong><br>
           <strong>Por concepto de: <?php echo e(lcfirst($recibo->descripcion)); ?></b> 

        </div>
        
        <br><br>
        <div class="row">
                                 <?php
                                    $saldo_ini = 0.00;
                                    $abono = 0.00;
                                    $SALDO = 0.00;
                                    
                            ?>
                                <table align ="center" border="1"cellspacing="0" style="font-size: small">
                                    <tbody cellspacing="0" cellpadding="5" width ="400px">
                                    <tr>
                                        <th align="right" style="padding-right: 50px;">Saldo inicial:</th>
                                        <td width ="190px" align="center"><b>L.<?php echo e(number_format($recibo->saldo_inicial, 2)); ?></b></td>
                                        
                                    </tr>
                                    <tr>
                                        <th width ="140px" align="right" style="padding-right: 50px;">Abono:</th>
                                        <td width ="190px" align="center"><b>L.<?php echo e(number_format($recibo->abono, 2)); ?></b></td>
                                        
                                    </tr>
                                    
                                    <?php 
                                        $saldo_ini = $recibo->saldo_inicial;
                                        $abono = $recibo->abono;
                                        $SALDO = $saldo_ini -$abono;


                                     ?>

                                    <tr>
                                        <th width ="140px" align="right" style="padding-right: 50px;">Saldo:</th>
                                        <td width ="190px" align="center"><b>L.<?php echo e(number_format($SALDO, 2)); ?></b></td>
                                        
                                    </tr>
 
                                    </tbody>

                                    
                                </table>
        </div>
        <br>
        <div class="row" align="center">
                        <strong style="font-size: small;">Tegucigalpa M.D.C <?php echo e(strtolower(strftime("%d de %B de %Y", strtotime($recibo->fecha)))); ?></strong>
        </div>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <br><br><br><br>

        <div class="footer">
            <div class="col-sm">
              <p style="font-size: small" align="center">Julio Cesar Santos<br>
                Jefe de Negocios y Proyectos
            </p>
        </div>
    </div>
    </div>
</div>
<!--     <div class="row">
        <div class="col-sm">
          <p align="center" style="font-size: small">
            "La factura es beneficio de todos, exíjala"
          </p>  
        </div>
    </div> -->

    
    

</div><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/receipts/create.blade.php ENDPATH**/ ?>