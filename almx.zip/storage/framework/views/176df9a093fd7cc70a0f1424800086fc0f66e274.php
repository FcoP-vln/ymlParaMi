
<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.products.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.product.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.product.title')); ?> - <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Product">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.product.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.product.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.product.fields.description')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($product->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($product->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($product->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($product->description ?? ''); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.products.show', $product->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.products.edit', $product->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_delete')): ?>
                                    <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!--*********************************Accesorio por producto***********************************************************-->
<br><br>

<h1>Accesorio por producto</h1>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.list')); ?>

    </div>
 
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-AccesoryProduct">
              
                <thead> 

                    <tr data-entry-id="<?php echo e($product->id); ?>">
                        <th width="10">

                        </th>
                        <th>
                            Producto_ID
                        </th>
                        <th>
                            Accesorio_ID
                        </th>
                        <th>
                            Requiere:
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
              
                <tbody>                    
                 <?php $__currentLoopData = $accesory_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accesory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr >
                            <td scope="row">
                              <!-- <?php echo e($accesory->id); ?> -->
                            </td>
                            <td>
                               <?php echo e($accesory->product_id ?? ''); ?>

                            </td>
                            <td>
                              <!-- <?php echo e($accesory->accesory_id); ?> -->
                                


                                <?php 
                                $name=DB::table('accesories')->select('accesories.name')->where('accesories.id','=',$accesory->accesory_id)->get();
                                foreach ($name as $nombre) {
                                echo $nombre->name ?? '';
                                }
                                ?>  
                       
                            </td>
                            <td class="text-center">
                                <?php echo e($accesory->required ?? ''); ?>

                            </td>  
                            <td>
                               <div class="text-center">
                                <div = "btn-group">
                            
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_edit')): ?>
                                <a class="btn btn-xs btn-warning pull-right" data-toggle="modal" href="#edit<?php echo e($accesory->id); ?>">Editar</a>
                                <?php endif; ?>

                                    </div>
                                </div>
                         
                            </td>
                          
                        </tr>
 <!-- MODAL EDITAR-->
  <div class="modal fade" id="edit<?php echo e($accesory->id); ?>" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button>
               
            </div>
            <div class="modal-body">
               <div class="card">
                <div class="card-body">
               <form id="formAP" action="<?php echo e(route('admin.accesory_product.update', $accesory)); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('PUT')); ?>

               
               <div class="form-group">

                <input type="hidden"  name="id" value="<?php echo e($accesory->id); ?>"><br>

                <b> PRODUCTO:</b>
              <input type="text" name="product_id" class="form-control" value="<?php echo e($accesory->product_id); ?>" readonly>
             
                <b>Accesorio:</b>
               <input type="text" name="" class="form-control" value="<?php echo e($nombre->name ?? ''); ?>" readonly>
        
             
              </div>
            </div>
            <div class="card-footer">
              <div class="form-group">
             <b> Requiere:</b>
              <input type="number" style="text-align:center" id="required" step="1" min="1" name="required" value="<?php echo e($accesory->required); ?>"><b> unidades.</b>
            </div>
          </div>
            </div>
            </div>
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Guardar">
            </div>
          </form>
      </div>
    </div>
</div>
</div>
    
<!-- fin modal -->






               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
      </div>
    </div>   
</div>


           
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.products.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'asc' ]],
    pageLength: 5,
  });
  $('.datatable-Product:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });

});


</script>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)


  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'asc' ]],
    pageLength: 5,
  });
  $('.datatable-AccesoryProduct:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });

});
    

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/products/index.blade.php ENDPATH**/ ?>